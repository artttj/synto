"use strict";(()=>{var m={TEMPLATES:"apc_templates",SETTINGS:"apc_settings",OPENAI_KEY:"apc_openai_key",GROK_KEY:"apc_grok_key",GEMINI_KEY:"apc_gemini_key"},g=["Understand","Decide","Act","Compose"],P=new Set(["default-structured-brief","analyze-article","community-debate-map","default-clean","extract-key-questions","lifestyle-recipe-card","lifestyle-buy-decision"]),v=[{id:"eng-ticket-analysis",name:"Ticket Analysis",label:"Ticket",description:"Summary, criteria, risks, next steps",category:"Understand",isDefault:!1,prompt:`You are a senior product engineer. Analyze ONLY the ticket below \u2014 do not invent information. Produce a developer-ready implementation brief.

Output ONLY the following markdown structure \u2014 nothing before or after:

## Summary
One crisp sentence: what is requested and why it matters.

## Goals
- 1\u20133 must-achieve outcomes

## Acceptance Criteria
1. Numbered, specific, testable conditions

## Technical Approach
High-level plan: steps, affected modules/APIs/DB changes, external dependencies.

## Tasks
- Task \xB7 Role (dev/qa/ux) \xB7 Estimate (S/M/L/XL) \xB7 Dependencies

## Risks & Mitigations
- Risk \u2192 mitigation (top 3 only)

## Open Questions
- Clarifications needed from author or stakeholders

## Priority
Low / Medium / High / Critical \u2014 one-sentence rationale

---

Ticket: [{title}]({url})

{content}`},{id:"eng-pr-review",name:"PR Review",label:"Code Review",description:"Changes, concerns, approvals, status",category:"Understand",isDefault:!1,prompt:`You are an elite code reviewer. Analyze ONLY the PR content below. Produce a concise, actionable review brief.

Output ONLY this exact markdown structure \u2014 nothing before or after:

## Summary
One paragraph: what the PR actually does and its intent.

## Impacted Areas
- Key files / modules / systems changed

## Findings

**Bugs / Logic**
- Issue \xB7 Severity (critical/high/medium/low) \xB7 Suggested fix

**Security / Performance**
- Issue \xB7 Severity \xB7 Suggested fix

**Tests / Coverage**
- Issue \xB7 Severity \xB7 Suggested fix

**Style / Maintainability**
- Issue \xB7 Severity \xB7 Suggested fix

## Test Recommendations
- What needs verification, missing test cases, quick smoke steps

## Verdict
Approve as-is / Approve with changes / Major rework needed / Reject \u2014 one-sentence reason.

## Post-Merge Follow-ups
- Optional cleanups / tech-debt items

---

Source: [{title}]({url})

{content}`},{id:"understand-structured-brief",name:"Structured Brief",label:"Brief",description:"Topic, key points, conclusions, open questions",category:"Understand",isDefault:!0,prompt:`You are a senior content analyst. Create a tight briefing from ONLY the source below. Do not add external facts.

Output ONLY this structure \u2014 nothing before or after:

## TL;DR
One powerful sentence summary.

## Audience
Who this is written for (persona, role, experience level).

## Key Takeaways
- 3\u20135 sharp, memorable bullets

## Evidence & Context
- 3\u20135 strongest claims, quotes, or data points from the source

## Conclusions
What was resolved, concluded, or recommended? Write "None yet" if unclear.

## Open Questions
What remains unclear, unresolved, or worth challenging?

---

Source: [{title}]({url})

{content}`},{id:"decide-brief",name:"Decision Brief",label:"Decision",description:"Options, trade-offs, recommendation",category:"Decide",isDefault:!1,prompt:`You are a principal decision architect. Using ONLY the context below, produce a short, executive-ready decision document.

Output ONLY the markdown below \u2014 nothing before or after:

## Context
2\u20134 sentences of background.

## Decision
One clear sentence: what exactly needs to be chosen.

## Options Compared

**Option A: [name]**
- Pros
- Cons
- Effort / Cost
- Time-to-value

**Option B: [name]**
- Pros
- Cons
- Effort / Cost
- Time-to-value

## Evaluation Criteria
- Criterion 1 (weight if scored)
(4\u20136 total)

## Recommendation
Chosen option + 2-sentence rationale anchored to the criteria.

## Next Actions
1. Step \xB7 Owner \xB7 Due \xB7 Metric
(3\u20134 items)

---

Source: [{title}]({url})

{content}`},{id:"decide-feature-request",name:"Feature Request Analysis",label:"Feature",description:"Problem, trade-offs, alternatives",category:"Decide",isDefault:!1,prompt:`You are a senior product engineer specializing in requirements distillation. Analyze ONLY the feature request below.

Output ONLY this structure \u2014 nothing before or after:

## Core Problem
One sentence: the real user pain or goal.

## User Stories
- As a [role], I want [feature] so that [benefit]
(3\u20134 stories)

## Acceptance Criteria
1. Numbered, testable conditions

## Edge Cases & Non-Functional
- Important boundaries, performance, security, accessibility needs

## MVP Scope
- In: \u2026
- Out / Later: \u2026

## Effort Sketch
Frontend: S / M / L
Backend: S / M / L
Infra / Other: S / M / L

---

Source: [{title}]({url})

{content}`},{id:"eng-action-items",name:"Extract Actions",label:"Actions",description:"Actions, next steps, blockers",category:"Act",isDefault:!1,prompt:`Extract every concrete action item from the content below. Output ONLY a numbered list \u2014 no introduction, no extra sentences.

Format each item:
1. **Action**: clear verb phrase
   **Owner**: role or person (infer if not explicit)
   **Due**: date / ASAP / none
   **Priority**: High / Medium / Low
   **Evidence**: short quote supporting this action

---

Source: [{title}]({url})

{content}`},{id:"extract-risks-blockers",name:"Risks & Blockers",label:"Risks",description:"Risks, blockers, assumptions",category:"Act",isDefault:!1,prompt:`Identify the most important risks and blockers from the content below. Output ONLY up to 8 items in this exact format \u2014 nothing else:

- **Title**: short name
  **Description**: 1\u20132 sentences
  **Likelihood**: Low / Medium / High
  **Impact**: Low / Medium / High / Critical
  **Mitigation**: concrete next step
  **Owner**: who should handle this
  **Escalation**: if stalled after 3 days \u2192 who / how

---

Source: [{title}]({url})

{content}`},{id:"lifestyle-smart-choice",name:"Smart Choice",label:"Recommend",description:"Options, trade-offs, quick verdict",category:"Act",isDefault:!1,prompt:`Score and decide between the options in the content below. Use a weighted scorecard. Output ONLY this structure \u2014 nothing before or after:

## Criteria (total weight 100)
- Criterion 1 \u2013 weight %
(4\u20136 criteria)

## Scorecard
| Option | Crit 1 | Crit 2 | Crit 3 | Crit 4 | Total (weighted) |
|--------|--------|--------|--------|--------|------------------|
| \u2026      | \u2026      | \u2026      | \u2026      | \u2026      | \u2026                |

## Winner
[Option name] \u2014 two-sentence explanation why it leads.

## Communication Snippet
Two sentences to tell stakeholders: benefit + immediate next step.

---

{content}`},{id:"write-compose-answer",name:"Draft Reply",label:"Reply",description:"Direct reply to a question or request",category:"Compose",isDefault:!1,prompt:`Draft a short, professional-yet-friendly reply for Slack or email based ONLY on the context below. Max 5\u20136 sentences.

Output ONLY the reply body text \u2014 no labels, no extras.

Structure: Start with an acknowledgment. Then give a direct answer or next step. Then a clear call-to-action (action + owner + due if relevant). End with a warm close.

---

{content}`},{id:"community-rewrite-comment",name:"Rewrite Comment",label:"Rewrite",description:"Professional, constructive rewrite",category:"Compose",isDefault:!1,prompt:`Rewrite the comment below to be professional, concise, and constructive while keeping the original meaning intact.

Output ONLY:

**Variant A \u2013 Short & direct**
(1\u20132 sentences)

**Variant B \u2013 Collaborative tone**
(2\u20134 sentences, warmer)

---

{content}`},{id:"write-email-helper",name:"Email Helper",label:"Email",description:"Short professional email draft",category:"Compose",isDefault:!1,prompt:`Write a professional, friendly email using ONLY the context below.

Output ONLY these four blocks \u2014 nothing before or after:

**Subject**
[6\u201310 words]

**Body**
(120\u2013180 words, natural tone)

**Sign-off choices**
1. Best regards, [Name]
2. Thanks & best, [Name]
3. Looking forward, [Name]

**Meeting proposals** (if scheduling is needed, next 1\u20132 business days)
- [Day, time]
- [Alternative day, time]

---

{content}`}];async function T(){return(await chrome.storage.local.get(m.OPENAI_KEY))[m.OPENAI_KEY]??""}async function N(e){await chrome.storage.local.set({[m.OPENAI_KEY]:e})}async function S(){return(await chrome.storage.local.get(m.GROK_KEY))[m.GROK_KEY]??""}async function _(e){await chrome.storage.local.set({[m.GROK_KEY]:e})}async function L(){return(await chrome.storage.local.get(m.GEMINI_KEY))[m.GEMINI_KEY]??""}async function H(e){await chrome.storage.local.set({[m.GEMINI_KEY]:e})}async function K(){let n=(await chrome.storage.local.get(m.TEMPLATES))[m.TEMPLATES];if(!n)return v;let o=new Map(v.map(i=>[i.id,i])),a=n.filter(i=>!P.has(i.id)).map(i=>{let u=o.get(i.id);return u?{...i,name:u.name,label:u.label,category:u.category,description:u.description}:i}),l=new Set(a.map(i=>i.id)),c=v.filter(i=>!l.has(i.id));return c.length>0?[...a,...c]:a}async function O(e){await chrome.storage.local.set({[m.TEMPLATES]:e})}async function w(){return{defaultTemplateId:"understand-structured-brief",theme:"dark",llmProvider:"openai",...(await chrome.storage.sync.get(m.SETTINGS))[m.SETTINGS]}}async function D(e){let n=await w();await chrome.storage.sync.set({[m.SETTINGS]:{...n,...e}})}var d=e=>document.getElementById(e),t={defaultTplEl:null,providerSeg:null,themeSeg:null,btnSaveSettings:null,settingsSaved:null,navAiWarning:null,templateSearch:null,templateList:null,btnNewTemplate:null,modalOverlay:null,modalTitle:null,modalName:null,modalCategorySelect:null,modalCategoryInput:null,modalPrompt:null,modalCancel:null,modalClose:null,modalSave:null};function R(){t.defaultTplEl=d("default-template"),t.providerSeg=d("provider-segmented"),t.themeSeg=d("theme-segmented"),t.btnSaveSettings=d("btn-save-settings"),t.settingsSaved=d("settings-saved"),t.navAiWarning=d("nav-ai-warning"),t.templateSearch=d("template-search"),t.templateList=d("template-list"),t.btnNewTemplate=d("btn-new-template"),t.modalOverlay=d("modal-overlay"),t.modalTitle=d("modal-title"),t.modalName=d("modal-name"),t.modalCategorySelect=d("modal-category-select"),t.modalCategoryInput=d("modal-category-input"),t.modalPrompt=d("modal-prompt"),t.modalCancel=d("modal-cancel"),t.modalClose=d("modal-close"),t.modalSave=d("modal-save")}var s={templates:[],settings:{defaultTemplateId:"default-structured-brief",theme:"dark",llmProvider:"openai"},editingId:null,searchQuery:""};function A(e){document.documentElement.dataset.theme=e}function Y(e,n,o){e.querySelectorAll(".seg-btn").forEach(r=>{r.dataset.value===n&&r.classList.add("active"),r.addEventListener("click",()=>{e.querySelectorAll(".seg-btn").forEach(a=>{a.classList.remove("active")}),r.classList.add("active"),o?.(r.dataset.value??"")})})}function G(e){return e.querySelector(".seg-btn.active")?.dataset.value}function b(){t.defaultTplEl.innerHTML="";let e={};for(let n of g)e[n]=[];s.templates.forEach(n=>{let o=n.category??"General";e[o]||(e[o]=[]),e[o].push(n)}),[...g,"Custom"].forEach(n=>{let o=e[n];if(!o?.length)return;let r=document.createElement("optgroup");r.label=n,o.forEach(a=>{let l=document.createElement("option");l.value=a.id,l.textContent=a.name,l.selected=a.id===s.settings.defaultTemplateId,r.appendChild(l)}),t.defaultTplEl.appendChild(r)})}function q(){b(),Y(t.providerSeg,s.settings.llmProvider??"openai"),Y(t.themeSeg,s.settings.theme??"dark",A)}function V(e){e.classList.remove("hidden"),setTimeout(()=>e.classList.add("hidden"),2e3)}function B(e){t.btnSaveSettings.addEventListener("click",async()=>{await D({defaultTemplateId:t.defaultTplEl.value,theme:G(t.themeSeg)??"dark",llmProvider:G(t.providerSeg)??"openai"}),s.settings=await e(),V(t.settingsSaved)})}function W(e){e.classList.remove("hidden"),setTimeout(()=>{e.classList.add("hidden")},2e3)}function x(e,n){let o=document.getElementById(e);o&&(o.textContent=n?"Connected":"Not Configured",o.className="status-badge "+(n?"connected":"unconfigured"))}async function k(){let[e,n,o]=await Promise.all([T(),L(),S()]);x("badge-openai",!!e),x("badge-gemini",!!n),x("badge-grok",!!o),t.navAiWarning.classList.toggle("hidden",!!(e&&n&&o))}function C({inputId:e,toggleId:n,saveId:o,clearId:r,savedId:a,getKey:l,saveKey:c}){let i=document.getElementById(e),u=document.getElementById(n),p=document.getElementById(o),M=document.getElementById(r),E=document.getElementById(a);l().then(f=>{f&&(i.value=f)}),u.addEventListener("click",()=>{i.type=i.type==="password"?"text":"password"}),p.addEventListener("click",async()=>{await c(i.value.trim()),await k(),W(E)}),M.addEventListener("click",async()=>{i.value="",await c(""),await k(),W(E)})}function I(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Q(e){let n=t.modalCategorySelect;n.innerHTML="";let o=new Set(g),r=new Set;for(let c of s.templates)c.category&&!o.has(c.category)&&r.add(c.category);let a=[...g,...[...r].sort()];for(let c of a){let i=document.createElement("option");i.value=c,i.textContent=c,n.appendChild(i)}let l=document.createElement("option");l.value="__new__",l.textContent="New category\u2026",n.appendChild(l),e&&a.includes(e)?n.value=e:n.value=a[0],t.modalCategoryInput.classList.add("hidden")}function F(e){s.editingId=e;let n=e?s.templates.find(o=>o.id===e):null;t.modalTitle.textContent=n?"Edit Template":"New Template",t.modalName.value=n?.name??"",t.modalPrompt.value=n?.prompt??"{content}",Q(n?.category),t.modalOverlay.classList.remove("hidden"),t.modalName.focus()}function y(){t.modalOverlay.classList.add("hidden"),s.editingId=null}function h(){t.templateList.innerHTML="";let e=s.searchQuery.toLowerCase(),n={};for(let a of g)n[a]=[];s.templates.forEach(a=>{if(e&&!a.name.toLowerCase().includes(e)&&!a.prompt.toLowerCase().includes(e))return;let l=a.category??"Custom";n[l]||(n[l]=[]),n[l].push(a)});let o=[...g,"Custom"],r=0;if(o.forEach(a=>{let l=n[a];if(!l?.length)return;r+=l.length;let c=document.createElement("div");c.className="template-category open";let i=document.createElement("button");i.className="category-toggle",i.setAttribute("type","button"),i.innerHTML=`
      ${I(a)}
      <span class="category-count">${l.length}</span>
      <svg class="category-chevron" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5">
        <path d="M5 7.5l5 5 5-5"/>
      </svg>
    `,i.addEventListener("click",()=>{c.classList.toggle("open")});let u=document.createElement("div");u.className="category-items",l.forEach(p=>{let M=v.some($=>$.id===p.id),E=p.prompt.replace(/\n/g," ").slice(0,90)+(p.prompt.length>90?"\u2026":""),f=document.createElement("div");f.className="template-item",f.innerHTML=`
        <div class="template-item-info">
          <div class="template-name">
            ${I(p.name)}
            ${M?'<span class="template-badge">built-in</span>':""}
          </div>
          <div class="template-preview">${I(E)}</div>
        </div>
        <div class="template-actions">
          <button class="btn btn-ghost btn-sm btn-edit" data-id="${p.id}" type="button">Edit</button>
          <button class="btn btn-danger btn-delete" data-id="${p.id}" type="button">Delete</button>
        </div>
      `,u.appendChild(f)}),c.appendChild(i),c.appendChild(u),t.templateList.appendChild(c)}),r===0){let a=document.createElement("div");a.className="no-results",a.textContent=e?`No templates matching "${e}"`:"No templates yet.",t.templateList.appendChild(a)}t.templateList.querySelectorAll(".btn-edit").forEach(a=>{a.addEventListener("click",()=>{F(a.dataset.id)})}),t.templateList.querySelectorAll(".btn-delete").forEach(a=>{a.addEventListener("click",()=>{z(a.dataset.id)})})}async function z(e){confirm("Delete this template?")&&(s.templates=s.templates.filter(n=>n.id!==e),await O(s.templates),h(),b())}function U(){t.templateSearch.addEventListener("input",e=>{s.searchQuery=e.target.value.trim(),h()}),t.btnNewTemplate.addEventListener("click",()=>{F(null)}),t.modalCancel.addEventListener("click",y),t.modalClose.addEventListener("click",y),t.modalOverlay.addEventListener("click",e=>{e.target===t.modalOverlay&&y()}),document.addEventListener("keydown",e=>{e.key==="Escape"&&y()}),document.querySelectorAll(".chip").forEach(e=>{e.addEventListener("click",()=>{let n=e.dataset.placeholder??"",o=t.modalPrompt.selectionStart??0,r=t.modalPrompt.selectionEnd??0,a=t.modalPrompt.value;t.modalPrompt.value=a.slice(0,o)+n+a.slice(r),t.modalPrompt.focus(),t.modalPrompt.setSelectionRange(o+n.length,o+n.length)})}),t.modalCategorySelect.addEventListener("change",()=>{let e=t.modalCategorySelect.value==="__new__";t.modalCategoryInput.classList.toggle("hidden",!e),e&&t.modalCategoryInput.focus()}),t.modalSave.addEventListener("click",async()=>{let e=t.modalName.value.trim(),n=t.modalPrompt.value.trim();if(!e){t.modalName.focus();return}if(!n){t.modalPrompt.focus();return}let o;if(t.modalCategorySelect.value==="__new__"){if(o=t.modalCategoryInput.value.trim(),!o){t.modalCategoryInput.focus();return}}else o=t.modalCategorySelect.value;s.editingId?s.templates=s.templates.map(r=>r.id===s.editingId?{...r,name:e,category:o,prompt:n}:r):s.templates.push({id:crypto.randomUUID(),name:e,category:o,prompt:n,isDefault:!1}),await O(s.templates),h(),b(),y()})}async function j(){R();let[e,n]=await Promise.all([K(),w()]);s.templates=e,s.settings=n,A(s.settings.theme??"dark"),q(),h();let o=chrome.runtime.getManifest(),r=document.getElementById("about-version");r&&(r.textContent=o.version),await k(),B(w),C({inputId:"openai-key",toggleId:"btn-toggle-key",saveId:"btn-save-key",clearId:"btn-clear-key",savedId:"key-saved",getKey:T,saveKey:N}),C({inputId:"gemini-key",toggleId:"btn-toggle-gemini-key",saveId:"btn-save-gemini-key",clearId:"btn-clear-gemini-key",savedId:"gemini-key-saved",getKey:L,saveKey:H}),C({inputId:"grok-key",toggleId:"btn-toggle-grok-key",saveId:"btn-save-grok-key",clearId:"btn-clear-grok-key",savedId:"grok-key-saved",getKey:S,saveKey:_}),U();function a(c){document.querySelectorAll(".nav-item").forEach(p=>p.classList.remove("active")),document.querySelectorAll(".tab-panel").forEach(p=>p.classList.add("hidden"));let i=document.querySelector(`.nav-item[data-tab="${c}"]`);i&&i.classList.add("active");let u=document.getElementById(`tab-${c}`);u&&u.classList.remove("hidden"),t.btnNewTemplate.classList.toggle("hidden",c!=="prompt-library")}document.querySelectorAll(".nav-item").forEach(c=>{c.addEventListener("click",()=>{a(c.dataset.tab)})});let l=location.hash.replace("#","");l&&document.querySelector(`.nav-item[data-tab="${l}"]`)&&a(l)}j().catch(e=>{console.error("[Synto] Init failed:",e instanceof Error?e.message:String(e))});})();

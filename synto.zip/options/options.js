"use strict";(()=>{var u={TEMPLATES:"apc_templates",SETTINGS:"apc_settings",OPENAI_KEY:"apc_openai_key",GROK_KEY:"apc_grok_key",GEMINI_KEY:"apc_gemini_key"},f=["Understand","Decide","Act","Compose"],B=new Set(["default-structured-brief","analyze-article","community-debate-map","default-clean","extract-key-questions","lifestyle-recipe-card","lifestyle-buy-decision"]),y=[{id:"eng-ticket-analysis",name:"Ticket Analysis",label:"Ticket",description:"Summary, criteria, risks, next steps",category:"Understand",isDefault:!1,prompt:`You are a senior product engineer. Analyze ONLY the ticket below \u2014 do not invent information. Produce a developer-ready implementation brief.

Output ONLY the following markdown structure \u2014 nothing before or after:

## Summary
One crisp sentence: what is requested and why it matters.

## Goals
- 1\u20133 must-achieve outcomes

## Acceptance Criteria
1. Numbered, specific, testable conditions

## Technical Approach
High-level plan: steps, affected modules/APIs/DB changes, external dependencies.

## Tasks
- Task \xB7 Role (dev/qa/ux) \xB7 Estimate (S/M/L/XL) \xB7 Dependencies

## Risks & Mitigations
- Risk \u2192 mitigation (top 3 only)

## Open Questions
- Clarifications needed from author or stakeholders

## Priority
Low / Medium / High / Critical \u2014 one-sentence rationale

---

Ticket: [{title}]({url})

{content}`},{id:"eng-pr-review",name:"PR Review",label:"Code Review",description:"Changes, concerns, approvals, status",category:"Understand",isDefault:!1,prompt:`You are an elite code reviewer. Analyze ONLY the PR content below. Produce a concise, actionable review brief.

Output ONLY this exact markdown structure \u2014 nothing before or after:

## Summary
One paragraph: what the PR actually does and its intent.

## Impacted Areas
- Key files / modules / systems changed

## Findings

**Bugs / Logic**
- Issue \xB7 Severity (critical/high/medium/low) \xB7 Suggested fix

**Security / Performance**
- Issue \xB7 Severity \xB7 Suggested fix

**Tests / Coverage**
- Issue \xB7 Severity \xB7 Suggested fix

**Style / Maintainability**
- Issue \xB7 Severity \xB7 Suggested fix

## Test Recommendations
- What needs verification, missing test cases, quick smoke steps

## Verdict
Approve as-is / Approve with changes / Major rework needed / Reject \u2014 one-sentence reason.

## Post-Merge Follow-ups
- Optional cleanups / tech-debt items

---

Source: [{title}]({url})

{content}`},{id:"understand-structured-brief",name:"Structured Brief",label:"Brief",description:"Topic, key points, conclusions, open questions",category:"Understand",isDefault:!0,prompt:`You are a senior content analyst. Create a tight briefing from ONLY the source below. Do not add external facts.

Output ONLY this structure \u2014 nothing before or after:

## TL;DR
One powerful sentence summary.

## Audience
Who this is written for (persona, role, experience level).

## Key Takeaways
- 3\u20135 sharp, memorable bullets

## Evidence & Context
- 3\u20135 strongest claims, quotes, or data points from the source

## Conclusions
What was resolved, concluded, or recommended? Write "None yet" if unclear.

## Open Questions
What remains unclear, unresolved, or worth challenging?

---

Source: [{title}]({url})

{content}`},{id:"decide-brief",name:"Decision Brief",label:"Decision",description:"Options, trade-offs, recommendation",category:"Decide",isDefault:!1,prompt:`You're helping a friend decide. Read the content, figure out what it is, and respond accordingly.

If it's a movie, show, book, album, or anything creative: be a sharp critic. Pick a side \u2014 worth it or skip it. No hedging, no "it depends." Use "I" statements. Mediocre means no. End with a VERDICT that includes a star rating using \u2B50 and \u2606 and a score like 3.5/5.

If it's a restaurant, menu, or food: be a helpful friend who knows food. Point out the best dishes, flag healthy or light options, mention anything to avoid. No harsh criticism \u2014 just honest, useful picks. End with a VERDICT.

For anything else: make a clear call. Pick the best option and say why in two sentences. No sitting on the fence. End with a VERDICT.

Talk like a person. Short sentences. No jargon, no filler, no review clich\xE9s. Nothing before or after the analysis and VERDICT.

---

{content}`},{id:"decide-feature-request",name:"Feature Request Analysis",label:"Feature",description:"Problem, trade-offs, alternatives",category:"Decide",isDefault:!1,prompt:`You are a senior product engineer specializing in requirements distillation. Analyze ONLY the feature request below.

Output ONLY this structure \u2014 nothing before or after:

## Core Problem
One sentence: the real user pain or goal.

## User Stories
- As a [role], I want [feature] so that [benefit]
(3\u20134 stories)

## Acceptance Criteria
1. Numbered, testable conditions

## Edge Cases & Non-Functional
- Important boundaries, performance, security, accessibility needs

## MVP Scope
- In: \u2026
- Out / Later: \u2026

## Effort Sketch
Frontend: S / M / L
Backend: S / M / L
Infra / Other: S / M / L

---

Source: [{title}]({url})

{content}`},{id:"eng-action-items",name:"Extract Actions",label:"Actions",description:"Actions, next steps, blockers",category:"Act",isDefault:!1,prompt:`Extract every concrete action item from the content below. Output ONLY a numbered list \u2014 no introduction, no extra sentences.

Format each item:
1. **Action**: clear verb phrase
   **Owner**: role or person (infer if not explicit)
   **Due**: date / ASAP / none
   **Priority**: High / Medium / Low
   **Evidence**: short quote supporting this action

---

Source: [{title}]({url})

{content}`},{id:"extract-risks-blockers",name:"Risks & Blockers",label:"Risks",description:"Risks, blockers, assumptions",category:"Act",isDefault:!1,prompt:`Identify the most important risks and blockers from the content below. Output ONLY up to 8 items in this exact format \u2014 nothing else:

- **Title**: short name
  **Description**: 1\u20132 sentences
  **Likelihood**: Low / Medium / High
  **Impact**: Low / Medium / High / Critical
  **Mitigation**: concrete next step
  **Owner**: who should handle this
  **Escalation**: if stalled after 3 days \u2192 who / how

---

Source: [{title}]({url})

{content}`},{id:"lifestyle-smart-choice",name:"Smart Choice",label:"Recommend",description:"Options, trade-offs, quick verdict",category:"Act",isDefault:!1,prompt:`You're helping a friend pick the best option. Read the content, figure out what it is, and respond accordingly.

If it's a movie, show, book, album, or anything creative: be a sharp critic. Love it or hate it \u2014 no middle ground. Use "I" statements. Mediocre means no. End with a VERDICT that includes a star rating using \u2B50 and \u2606 and a score like 3.5/5.

If it's a restaurant menu or food: be a helpful advisor. Pick the best dishes, flag healthy and light options, call out anything worth skipping. Practical and direct \u2014 not harsh. End with a VERDICT.

For anything else: name the best option and say why. One clear pick, no hedging. End with a VERDICT.

Talk like a person. Short sentences. No jargon, no filler, no review clich\xE9s. Nothing before or after the analysis and VERDICT.

---

{content}`},{id:"write-compose-answer",name:"Draft Reply",label:"Reply",description:"Direct reply to a question or request",category:"Compose",isDefault:!1,prompt:`Draft a short, professional-yet-friendly reply for Slack or email based ONLY on the context below. Max 5\u20136 sentences.

Output ONLY the reply body text \u2014 no labels, no extras.

Structure: Start with an acknowledgment. Then give a direct answer or next step. Then a clear call-to-action (action + owner + due if relevant). End with a warm close.

---

{content}`},{id:"community-rewrite-comment",name:"Rewrite Comment",label:"Rewrite",description:"Professional, constructive rewrite",category:"Compose",isDefault:!1,prompt:`Rewrite the comment below to be professional, concise, and constructive while keeping the original meaning intact.

Output ONLY:

**Variant A \u2013 Short & direct**
(1\u20132 sentences)

**Variant B \u2013 Collaborative tone**
(2\u20134 sentences, warmer)

---

{content}`},{id:"write-email-helper",name:"Email Helper",label:"Email",description:"Short professional email draft",category:"Compose",isDefault:!1,prompt:`Write a professional, friendly email using ONLY the context below.

Output ONLY these four blocks \u2014 nothing before or after:

**Subject**
[6\u201310 words]

**Body**
(120\u2013180 words, natural tone)

**Sign-off choices**
1. Best regards, [Name]
2. Thanks & best, [Name]
3. Looking forward, [Name]

**Meeting proposals** (if scheduling is needed, next 1\u20132 business days)
- [Day, time]
- [Alternative day, time]

---

{content}`}];async function k(){return(await chrome.storage.local.get(u.OPENAI_KEY))[u.OPENAI_KEY]??""}async function Y(e){await chrome.storage.local.set({[u.OPENAI_KEY]:e})}async function w(){return(await chrome.storage.local.get(u.GROK_KEY))[u.GROK_KEY]??""}async function q(e){await chrome.storage.local.set({[u.GROK_KEY]:e})}async function S(){return(await chrome.storage.local.get(u.GEMINI_KEY))[u.GEMINI_KEY]??""}async function V(e){await chrome.storage.local.set({[u.GEMINI_KEY]:e})}async function F(){let n=(await chrome.storage.local.get(u.TEMPLATES))[u.TEMPLATES];if(!n)return y;let o=new Map(y.map(s=>[s.id,s])),a=n.filter(s=>!B.has(s.id)).map(s=>{let m=o.get(s.id);return m?{...s,name:m.name,label:m.label,category:m.category,description:m.description}:s}),c=new Set(a.map(s=>s.id)),l=y.filter(s=>!c.has(s.id));return l.length>0?[...a,...l]:a}async function O(e){await chrome.storage.local.set({[u.TEMPLATES]:e})}async function L(){return{defaultTemplateId:"understand-structured-brief",theme:"dark",llmProvider:"openai",language:"en",...(await chrome.storage.sync.get(u.SETTINGS))[u.SETTINGS]}}async function R(e){let n=await L();await chrome.storage.sync.set({[u.SETTINGS]:{...n,...e}})}var te={popup_preview:"Preview",popup_content_tab:"Content",popup_prompt_tab:"Prompt",popup_refresh_content:"Refresh content",popup_refresh_content_hint:"Re-extract page content \u2014 handy when AJAX loads after the page",popup_near_limit:"Near limit",popup_chat_placeholder:"Ask a follow-up\u2026",popup_no_key_prefix:"No API key set. Add it in\xA0",popup_options_link:"Options",popup_no_key_suffix:".",popup_copy_markdown:"Copy Markdown",popup_copy_prompt:"Copy Prompt",popup_copied:"Copied!",popup_ask_chatgpt:"Ask ChatGPT",popup_ask_gemini:"Ask Gemini",popup_ask_grok:"Ask Grok",popup_ask_ai:"Ask AI",popup_asking:"Asking\u2026",options_brand_sub:"Settings",options_nav_general:"General",options_nav_ai:"AI Connections",options_nav_library:"Prompt Library",options_nav_help:"Help",options_nav_about:"About",options_general_heading:"General",options_general_desc:"Configure default behaviour when the extension opens.",options_default_template:"Default Template",options_default_template_desc:"Pre-selected prompt when the popup opens",options_ai_provider:"AI Provider",options_ai_provider_desc:"Which service runs the analysis",options_theme:"Theme",options_theme_desc:"Interface colour scheme",options_theme_dark:"Dark",options_theme_light:"Light",options_language:"Language",options_language_desc:"Interface language",options_save:"Save Settings",options_saved:"\u2713 Saved",options_ai_heading:"AI Connections",options_ai_desc:"API keys are stored locally on your device and are never transmitted by this extension.",options_library_heading:"Prompt Library",options_library_desc:"Browse, search, and manage your prompt templates.",options_search_placeholder:"Search templates\u2026",options_help_heading:"Help",options_help_desc:"How Synto works and keyboard shortcuts.",options_about_heading:"About Synto",options_builtin:"built-in",options_new_template:"New Template",options_new_template_title:"Add new template",options_edit_template:"Edit Template",options_new_category:"New category\u2026",options_delete:"Delete",options_edit:"Edit",options_cancel:"Cancel",options_save_template:"Save Template",options_template_name_placeholder:"Template name",options_template_prompt_placeholder:"Write your prompt here\u2026",options_delete_confirm:"Delete this template?",options_no_results:"No templates yet.",options_no_results_search:'No templates matching\xA0"{q}"',status_connected:"Connected",status_not_configured:"Not Configured",error_no_key_openai:"No OpenAI API key. Add it in Options.",error_no_key_gemini:"No Gemini API key. Add it in Options.",error_no_key_grok:"No Grok API key. Add it in Options.",category_understand:"Understand",category_decide:"Decide",category_act:"Act",category_compose:"Compose",category_custom:"Custom","template_label_eng-ticket-analysis":"Ticket","template_label_eng-pr-review":"Code Review","template_label_understand-structured-brief":"Brief","template_label_decide-brief":"Decision","template_label_decide-feature-request":"Feature","template_label_eng-action-items":"Actions","template_label_extract-risks-blockers":"Risks","template_label_lifestyle-smart-choice":"Recommend","template_label_write-compose-answer":"Reply","template_label_community-rewrite-comment":"Rewrite","template_label_write-email-helper":"Email","template_name_eng-ticket-analysis":"Ticket Analysis","template_name_eng-pr-review":"PR Review","template_name_understand-structured-brief":"Structured Brief","template_name_decide-brief":"Decision Brief","template_name_decide-feature-request":"Feature Request Analysis","template_name_eng-action-items":"Extract Actions","template_name_extract-risks-blockers":"Risks & Blockers","template_name_lifestyle-smart-choice":"Smart Choice","template_name_write-compose-answer":"Draft Reply","template_name_community-rewrite-comment":"Rewrite Comment","template_name_write-email-helper":"Email Helper"},A=te;var ne={popup_preview:"Vorschau",popup_content_tab:"Inhalt",popup_prompt_tab:"Prompt",popup_refresh_content:"Inhalt aktualisieren",popup_refresh_content_hint:"Seite neu laden \u2014 hilfreich wenn AJAX-Inhalte nachgeladen werden",popup_near_limit:"Fast am Limit",popup_chat_placeholder:"Nachfrage stellen\u2026",popup_no_key_prefix:"Kein API-Schl\xFCssel. In den\xA0",popup_options_link:"Einstellungen",popup_no_key_suffix:"\xA0hinzuf\xFCgen.",popup_copy_markdown:"Markdown kopieren",popup_copy_prompt:"Prompt kopieren",popup_copied:"Kopiert!",popup_ask_chatgpt:"ChatGPT fragen",popup_ask_gemini:"Gemini fragen",popup_ask_grok:"Grok fragen",popup_ask_ai:"KI fragen",popup_asking:"Anfrage l\xE4uft\u2026",options_brand_sub:"Einstellungen",options_nav_general:"Allgemein",options_nav_ai:"AI-Verbindungen",options_nav_library:"Prompt-Bibliothek",options_nav_help:"Hilfe",options_nav_about:"\xDCber",options_general_heading:"Allgemein",options_general_desc:"Standardverhalten beim \xD6ffnen der Erweiterung festlegen.",options_default_template:"Standard-Template",options_default_template_desc:"Vorausgew\xE4hlter Prompt beim \xD6ffnen",options_ai_provider:"AI-Anbieter",options_ai_provider_desc:"Welcher Dienst die Analyse durchf\xFChrt",options_theme:"Theme",options_theme_desc:"Farbschema der Oberfl\xE4che",options_theme_dark:"Dunkel",options_theme_light:"Hell",options_language:"Sprache",options_language_desc:"Sprache der Benutzeroberfl\xE4che",options_save:"Einstellungen speichern",options_saved:"\u2713 Gespeichert",options_ai_heading:"AI-Verbindungen",options_ai_desc:"API-Schl\xFCssel werden lokal auf Ihrem Ger\xE4t gespeichert und nie \xFCbertragen.",options_library_heading:"Prompt-Bibliothek",options_library_desc:"Prompt-Templates durchsuchen und verwalten.",options_search_placeholder:"Templates suchen\u2026",options_help_heading:"Hilfe",options_help_desc:"So funktioniert Synto und Tastaturk\xFCrzel.",options_about_heading:"\xDCber Synto",options_builtin:"integriert",options_new_template:"Neues Template",options_new_template_title:"Neues Template hinzuf\xFCgen",options_edit_template:"Template bearbeiten",options_new_category:"Neue Kategorie\u2026",options_delete:"L\xF6schen",options_edit:"Bearbeiten",options_cancel:"Abbrechen",options_save_template:"Template speichern",options_template_name_placeholder:"Template-Name",options_template_prompt_placeholder:"Prompt hier eingeben\u2026",options_delete_confirm:"Dieses Template l\xF6schen?",options_no_results:"Keine Templates vorhanden.",options_no_results_search:'Keine Templates f\xFCr\xA0"{q}"',status_connected:"Verbunden",status_not_configured:"Nicht konfiguriert",error_no_key_openai:"Kein OpenAI API-Schl\xFCssel. Unter Einstellungen hinzuf\xFCgen.",error_no_key_gemini:"Kein Gemini API-Schl\xFCssel. Unter Einstellungen hinzuf\xFCgen.",error_no_key_grok:"Kein Grok API-Schl\xFCssel. Unter Einstellungen hinzuf\xFCgen.",category_understand:"Verstehen",category_decide:"Entscheiden",category_act:"Handeln",category_compose:"Verfassen",category_custom:"Benutzerdefiniert","template_label_eng-ticket-analysis":"Ticket","template_label_eng-pr-review":"Code Review","template_label_understand-structured-brief":"Briefing","template_label_decide-brief":"Entscheidung","template_label_decide-feature-request":"Feature","template_label_eng-action-items":"Aktionen","template_label_extract-risks-blockers":"Risiken","template_label_lifestyle-smart-choice":"Empfehlung","template_label_write-compose-answer":"Antwort","template_label_community-rewrite-comment":"Umschreiben","template_label_write-email-helper":"E-Mail","template_name_eng-ticket-analysis":"Ticket-Analyse","template_name_eng-pr-review":"PR Review","template_name_understand-structured-brief":"Strukturiertes Briefing","template_name_decide-brief":"Entscheidungshilfe","template_name_decide-feature-request":"Feature-Anfrage-Analyse","template_name_eng-action-items":"Aktionen extrahieren","template_name_extract-risks-blockers":"Risiken & Blocker","template_name_lifestyle-smart-choice":"Beste Wahl","template_name_write-compose-answer":"Antwort entwerfen","template_name_community-rewrite-comment":"Kommentar umschreiben","template_name_write-email-helper":"E-Mail-Assistent"},U=ne;var W=A;function I(e){W=e==="de"?U:A}function p(e){return W[e]??A[e]??e}function C(e=document){e.querySelectorAll("[data-i18n]").forEach(n=>{n.textContent=p(n.getAttribute("data-i18n"))}),e.querySelectorAll("[data-i18n-placeholder]").forEach(n=>{n.setAttribute("placeholder",p(n.getAttribute("data-i18n-placeholder")))}),e.querySelectorAll("[data-i18n-title]").forEach(n=>{n.setAttribute("title",p(n.getAttribute("data-i18n-title")))})}var d=e=>document.getElementById(e),t={defaultTplEl:null,providerSeg:null,themeSeg:null,languageSeg:null,btnSaveSettings:null,settingsSaved:null,navAiWarning:null,templateSearch:null,templateList:null,btnNewTemplate:null,modalOverlay:null,modalTitle:null,modalName:null,modalCategorySelect:null,modalCategoryInput:null,modalPrompt:null,modalCancel:null,modalClose:null,modalSave:null};function $(){t.defaultTplEl=d("default-template"),t.providerSeg=d("provider-segmented"),t.themeSeg=d("theme-segmented"),t.languageSeg=d("language-segmented"),t.btnSaveSettings=d("btn-save-settings"),t.settingsSaved=d("settings-saved"),t.navAiWarning=d("nav-ai-warning"),t.templateSearch=d("template-search"),t.templateList=d("template-list"),t.btnNewTemplate=d("btn-new-template"),t.modalOverlay=d("modal-overlay"),t.modalTitle=d("modal-title"),t.modalName=d("modal-name"),t.modalCategorySelect=d("modal-category-select"),t.modalCategoryInput=d("modal-category-input"),t.modalPrompt=d("modal-prompt"),t.modalCancel=d("modal-cancel"),t.modalClose=d("modal-close"),t.modalSave=d("modal-save")}var i={templates:[],settings:{defaultTemplateId:"default-structured-brief",theme:"dark",llmProvider:"openai"},editingId:null,searchQuery:""};function K(e){document.documentElement.dataset.theme=e}function H(e,n,o){e.querySelectorAll(".seg-btn").forEach(r=>{r.dataset.value===n&&r.classList.add("active"),r.addEventListener("click",()=>{e.querySelectorAll(".seg-btn").forEach(a=>{a.classList.remove("active")}),r.classList.add("active"),o?.(r.dataset.value??"")})})}function D(e){return e.querySelector(".seg-btn.active")?.dataset.value}function P(){t.defaultTplEl.innerHTML="";let e={};for(let n of f)e[n]=[];i.templates.forEach(n=>{let o=n.category??"General";e[o]||(e[o]=[]),e[o].push(n)}),[...f,"Custom"].forEach(n=>{let o=e[n];if(!o?.length)return;let r=document.createElement("optgroup");r.label=n,o.forEach(a=>{let c=document.createElement("option");c.value=a.id,c.textContent=a.name,c.selected=a.id===i.settings.defaultTemplateId,r.appendChild(c)}),t.defaultTplEl.appendChild(r)})}function z(){P(),H(t.providerSeg,i.settings.llmProvider??"openai"),H(t.themeSeg,i.settings.theme??"dark",K),H(t.languageSeg,i.settings.language??"en",e=>{I(e),C(),R({language:e})})}function ae(e){e.classList.remove("hidden"),setTimeout(()=>e.classList.add("hidden"),2e3)}function j(e){t.btnSaveSettings.addEventListener("click",async()=>{await R({defaultTemplateId:t.defaultTplEl.value,theme:D(t.themeSeg)??"dark",llmProvider:D(t.providerSeg)??"openai",language:D(t.languageSeg)??"en"}),i.settings=await e(),ae(t.settingsSaved)})}function Q(e){e.classList.remove("hidden"),setTimeout(()=>{e.classList.add("hidden")},2e3)}function G(e,n){let o=document.getElementById(e);o&&(o.textContent=n?p("status_connected"):p("status_not_configured"),o.className="status-badge "+(n?"connected":"unconfigured"))}async function M(){let[e,n,o]=await Promise.all([k(),S(),w()]);G("badge-openai",!!e),G("badge-gemini",!!n),G("badge-grok",!!o),t.navAiWarning.classList.toggle("hidden",!!(e&&n&&o))}function x({inputId:e,toggleId:n,saveId:o,clearId:r,savedId:a,getKey:c,saveKey:l}){let s=document.getElementById(e),m=document.getElementById(n),g=document.getElementById(o),_=document.getElementById(r),b=document.getElementById(a);c().then(T=>{T&&(s.value=T)}),m.addEventListener("click",()=>{s.type=s.type==="password"?"text":"password"}),g.addEventListener("click",async()=>{await l(s.value.trim()),await M(),Q(b)}),_.addEventListener("click",async()=>{s.value="",await l(""),await M(),Q(b)})}function h(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function oe(e){let n=t.modalCategorySelect;n.innerHTML="";let o=new Set(f),r=new Set;for(let l of i.templates)l.category&&!o.has(l.category)&&r.add(l.category);let a=[...f,...[...r].sort()];for(let l of a){let s=document.createElement("option");s.value=l,s.textContent=p("category_"+l.toLowerCase())||l,n.appendChild(s)}let c=document.createElement("option");c.value="__new__",c.textContent=p("options_new_category"),n.appendChild(c),e&&a.includes(e)?n.value=e:n.value=a[0],t.modalCategoryInput.classList.add("hidden")}function X(e){i.editingId=e;let n=e?i.templates.find(o=>o.id===e):null;t.modalTitle.textContent=n?p("options_edit_template"):p("options_new_template"),t.modalName.value=n?.name??"",t.modalPrompt.value=n?.prompt??"{content}",oe(n?.category),t.modalOverlay.classList.remove("hidden"),t.modalName.focus()}function v(){t.modalOverlay.classList.add("hidden"),i.editingId=null}function E(){t.templateList.innerHTML="";let e=i.searchQuery.toLowerCase(),n={};for(let a of f)n[a]=[];i.templates.forEach(a=>{if(e&&!a.name.toLowerCase().includes(e)&&!a.prompt.toLowerCase().includes(e))return;let c=a.category??"Custom";n[c]||(n[c]=[]),n[c].push(a)});let o=[...f,"Custom"],r=0;if(o.forEach(a=>{let c=n[a];if(!c?.length)return;r+=c.length;let l=document.createElement("div");l.className="template-category open";let s=p("category_"+a.toLowerCase())||a,m=document.createElement("button");m.className="category-toggle",m.setAttribute("type","button"),m.innerHTML=`
      ${h(s)}
      <span class="category-count">${c.length}</span>
      <svg class="category-chevron" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5">
        <path d="M5 7.5l5 5 5-5"/>
      </svg>
    `,m.addEventListener("click",()=>{l.classList.toggle("open")});let g=document.createElement("div");g.className="category-items",c.forEach(_=>{let b=y.some(ee=>ee.id===_.id),T=p("template_name_"+_.id)||_.name,Z=_.prompt.replace(/\n/g," ").slice(0,90)+(_.prompt.length>90?"\u2026":""),N=document.createElement("div");N.className="template-item",N.innerHTML=`
        <div class="template-item-info">
          <div class="template-name">
            ${h(T)}
            ${b?`<span class="template-badge">${h(p("options_builtin"))}</span>`:""}
          </div>
          <div class="template-preview">${h(Z)}</div>
        </div>
        <div class="template-actions">
          <button class="btn btn-ghost btn-sm btn-edit" data-id="${_.id}" type="button">${h(p("options_edit"))}</button>
          <button class="btn btn-danger btn-delete" data-id="${_.id}" type="button">${h(p("options_delete"))}</button>
        </div>
      `,g.appendChild(N)}),l.appendChild(m),l.appendChild(g),t.templateList.appendChild(l)}),r===0){let a=document.createElement("div");a.className="no-results",a.textContent=e?p("options_no_results_search").replace("{q}",e):p("options_no_results"),t.templateList.appendChild(a)}t.templateList.querySelectorAll(".btn-edit").forEach(a=>{a.addEventListener("click",()=>{X(a.dataset.id)})}),t.templateList.querySelectorAll(".btn-delete").forEach(a=>{a.addEventListener("click",()=>{ie(a.dataset.id)})})}async function ie(e){confirm(p("options_delete_confirm"))&&(i.templates=i.templates.filter(n=>n.id!==e),await O(i.templates),E(),P())}function J(){t.templateSearch.addEventListener("input",e=>{i.searchQuery=e.target.value.trim(),E()}),t.btnNewTemplate.addEventListener("click",()=>{X(null)}),t.modalCancel.addEventListener("click",v),t.modalClose.addEventListener("click",v),t.modalOverlay.addEventListener("click",e=>{e.target===t.modalOverlay&&v()}),document.addEventListener("keydown",e=>{e.key==="Escape"&&v()}),document.querySelectorAll(".chip").forEach(e=>{e.addEventListener("click",()=>{let n=e.dataset.placeholder??"",o=t.modalPrompt.selectionStart??0,r=t.modalPrompt.selectionEnd??0,a=t.modalPrompt.value;t.modalPrompt.value=a.slice(0,o)+n+a.slice(r),t.modalPrompt.focus(),t.modalPrompt.setSelectionRange(o+n.length,o+n.length)})}),t.modalCategorySelect.addEventListener("change",()=>{let e=t.modalCategorySelect.value==="__new__";t.modalCategoryInput.classList.toggle("hidden",!e),e&&t.modalCategoryInput.focus()}),t.modalSave.addEventListener("click",async()=>{let e=t.modalName.value.trim(),n=t.modalPrompt.value.trim();if(!e){t.modalName.focus();return}if(!n){t.modalPrompt.focus();return}let o;if(t.modalCategorySelect.value==="__new__"){if(o=t.modalCategoryInput.value.trim(),!o){t.modalCategoryInput.focus();return}}else o=t.modalCategorySelect.value;i.editingId?i.templates=i.templates.map(r=>r.id===i.editingId?{...r,name:e,category:o,prompt:n}:r):i.templates.push({id:crypto.randomUUID(),name:e,category:o,prompt:n,isDefault:!1}),await O(i.templates),E(),P(),v()})}async function re(){$();let[e,n]=await Promise.all([F(),L()]);i.templates=e,i.settings=n,I(n.language??"en"),K(i.settings.theme??"dark"),C(),z(),E();let o=chrome.runtime.getManifest(),r=document.getElementById("about-version");r&&(r.textContent=o.version),await M(),j(L),x({inputId:"openai-key",toggleId:"btn-toggle-key",saveId:"btn-save-key",clearId:"btn-clear-key",savedId:"key-saved",getKey:k,saveKey:Y}),x({inputId:"gemini-key",toggleId:"btn-toggle-gemini-key",saveId:"btn-save-gemini-key",clearId:"btn-clear-gemini-key",savedId:"gemini-key-saved",getKey:S,saveKey:V}),x({inputId:"grok-key",toggleId:"btn-toggle-grok-key",saveId:"btn-save-grok-key",clearId:"btn-clear-grok-key",savedId:"grok-key-saved",getKey:w,saveKey:q}),J();function a(l){document.querySelectorAll(".nav-item").forEach(g=>g.classList.remove("active")),document.querySelectorAll(".tab-panel").forEach(g=>g.classList.add("hidden"));let s=document.querySelector(`.nav-item[data-tab="${l}"]`);s&&s.classList.add("active");let m=document.getElementById(`tab-${l}`);m&&m.classList.remove("hidden"),t.btnNewTemplate.classList.toggle("hidden",l!=="prompt-library")}document.querySelectorAll(".nav-item").forEach(l=>{l.addEventListener("click",()=>{a(l.dataset.tab)})});let c=location.hash.replace("#","");c&&document.querySelector(`.nav-item[data-tab="${c}"]`)&&a(c)}re().catch(e=>{console.error("[Synto] Init failed:",e instanceof Error?e.message:String(e))});})();

var e={TEMPLATES:"apc_templates",SETTINGS:"apc_settings",OPENAI_KEY:"apc_openai_key",GROK_KEY:"apc_grok_key",GEMINI_KEY:"apc_gemini_key",OPENROUTER_KEY:"apc_openrouter_key",ZAI_KEY:"apc_zai_key",ANTHROPIC_KEY:"apc_anthropic_key",CUSTOM_KEY:"apc_custom_key",OLLAMA_KEY:"apc_ollama_key",HISTORY:"apc_history"};var n=[{id:"eng-ticket-analysis",name:"Ticket Analysis",label:"Ticket",description:"Summary, criteria, risks, next steps",category:"Understand",isDefault:!1,prompt:`You are a senior product engineer. Analyze ONLY the ticket below \u2014 do not invent information. Produce a developer-ready implementation brief.

Output ONLY the following markdown structure \u2014 nothing before or after:

## Summary
One crisp sentence: what is requested and why it matters.

## Goals
- 1\u20133 must-achieve outcomes

## Acceptance Criteria
1. Numbered, specific, testable conditions

## Technical Approach
High-level plan: steps, affected modules/APIs/DB changes, external dependencies.

## Tasks
- Task \xB7 Role (dev/qa/ux) \xB7 Estimate (S/M/L/XL) \xB7 Dependencies

## Risks & Mitigations
- Risk \u2192 mitigation (top 3 only)

## Open Questions
- Clarifications needed from author or stakeholders

## Priority
Low / Medium / High / Critical \u2014 one-sentence rationale

---

Ticket: [{title}]({url})

{content}`},{id:"eng-pr-review",name:"PR Review",label:"Code Review",description:"Changes, concerns, approvals, status",category:"Understand",isDefault:!1,prompt:`You are an elite code reviewer. Analyze ONLY the PR content below. Produce a concise, actionable review brief.

Output ONLY this exact markdown structure \u2014 nothing before or after:

## Summary
One paragraph: what the PR actually does and its intent.

## Impacted Areas
- Key files / modules / systems changed

## Findings

**Bugs / Logic**
- Issue \xB7 Severity (critical/high/medium/low) \xB7 Suggested fix

**Security / Performance**
- Issue \xB7 Severity \xB7 Suggested fix

**Tests / Coverage**
- Issue \xB7 Severity \xB7 Suggested fix

**Style / Maintainability**
- Issue \xB7 Severity \xB7 Suggested fix

## Test Recommendations
- What needs verification, missing test cases, quick smoke steps

## Verdict
Approve as-is / Approve with changes / Major rework needed / Reject \u2014 one-sentence reason.

## Post-Merge Follow-ups
- Optional cleanups / tech-debt items

---

Source: [{title}]({url})

{content}`},{id:"understand-structured-brief",name:"Structured Brief",label:"Brief",description:"Topic, key points, conclusions, open questions",category:"Understand",isDefault:!0,prompt:`You are a senior content analyst. Create a tight briefing from ONLY the source below. Do not add external facts.

Output ONLY this structure \u2014 nothing before or after:

## TL;DR
One powerful sentence summary.

## Audience
Who this is written for (persona, role, experience level).

## Key Takeaways
- 3\u20135 sharp, memorable bullets

## Evidence & Context
- 3\u20135 strongest claims, quotes, or data points from the source

## Conclusions
What was resolved, concluded, or recommended? Write "None yet" if unclear.

## Open Questions
What remains unclear, unresolved, or worth challenging?

---

Source: [{title}]({url})

{content}`},{id:"decide-brief",name:"Decision Brief",label:"Decision",description:"Options, trade-offs, recommendation",category:"Decide",isDefault:!1,prompt:`You're helping a friend decide. Read the content, figure out what it is, and respond accordingly.

If it's a movie, show, book, album, or anything creative: be a sharp critic. Pick a side \u2014 worth it or skip it. No hedging, no "it depends." Use "I" statements. Mediocre means no. End with a VERDICT that includes a star rating using \u2B50 and \u2606 and a score like 3.5/5.

If it's a restaurant, menu, or food: be a helpful friend who knows food. Point out the best dishes, flag healthy or light options, mention anything to avoid. No harsh criticism \u2014 just honest, useful picks. End with a VERDICT.

For anything else: make a clear call. Pick the best option and say why in two sentences. No sitting on the fence. End with a VERDICT.

Talk like a person. Short sentences. No jargon, no filler, no review clich\xE9s. Nothing before or after the analysis and VERDICT.

---

{content}`},{id:"decide-feature-request",name:"Feature Request Analysis",label:"Feature",description:"Problem, trade-offs, alternatives",category:"Decide",isDefault:!1,prompt:`You are a senior product engineer specializing in requirements distillation. Analyze ONLY the feature request below.

Output ONLY this structure \u2014 nothing before or after:

## Core Problem
One sentence: the real user pain or goal.

## User Stories
- As a [role], I want [feature] so that [benefit]
(3\u20134 stories)

## Acceptance Criteria
1. Numbered, testable conditions

## Edge Cases & Non-Functional
- Important boundaries, performance, security, accessibility needs

## MVP Scope
- In: \u2026
- Out / Later: \u2026

## Effort Sketch
Frontend: S / M / L
Backend: S / M / L
Infra / Other: S / M / L

---

Source: [{title}]({url})

{content}`},{id:"eng-action-items",name:"Extract Actions",label:"Actions",description:"Actions, next steps, blockers",category:"Act",isDefault:!1,prompt:`Extract every concrete action item from the content below. Output ONLY a numbered list \u2014 no introduction, no extra sentences.

Format each item:
1. **Action**: clear verb phrase
   **Owner**: role or person (infer if not explicit)
   **Due**: date / ASAP / none
   **Priority**: High / Medium / Low
   **Evidence**: short quote supporting this action

---

Source: [{title}]({url})

{content}`},{id:"extract-risks-blockers",name:"Risks & Blockers",label:"Risks",description:"Risks, blockers, assumptions",category:"Act",isDefault:!1,prompt:`Identify the most important risks and blockers from the content below. Output ONLY up to 8 items in this exact format \u2014 nothing else:

- **Title**: short name
  **Description**: 1\u20132 sentences
  **Likelihood**: Low / Medium / High
  **Impact**: Low / Medium / High / Critical
  **Mitigation**: concrete next step
  **Owner**: who should handle this
  **Escalation**: if stalled after 3 days \u2192 who / how

---

Source: [{title}]({url})

{content}`},{id:"lifestyle-smart-choice",name:"Smart Choice",label:"Recommend",description:"Options, trade-offs, quick verdict",category:"Act",isDefault:!1,prompt:`You're helping a friend pick the best option. Read the content, figure out what it is, and respond accordingly.

If it's a movie, show, book, album, or anything creative: be a sharp critic. Love it or hate it \u2014 no middle ground. Use "I" statements. Mediocre means no. End with a VERDICT that includes a star rating using \u2B50 and \u2606 and a score like 3.5/5.

If it's a restaurant menu or food: be a helpful advisor. Pick the best dishes, flag healthy and light options, call out anything worth skipping. Practical and direct \u2014 not harsh. End with a VERDICT.

For anything else: name the best option and say why. One clear pick, no hedging. End with a VERDICT.

Talk like a person. Short sentences. No jargon, no filler, no review clich\xE9s. Nothing before or after the analysis and VERDICT.

---

{content}`},{id:"write-compose-answer",name:"Draft Reply",label:"Reply",description:"Direct reply to a question or request",category:"Compose",isDefault:!1,prompt:`Draft a short, professional-yet-friendly reply for Slack or email based ONLY on the context below. Max 5\u20136 sentences.

Output ONLY the reply body text \u2014 no labels, no extras.

Structure: Start with an acknowledgment. Then give a direct answer or next step. Then a clear call-to-action (action + owner + due if relevant). End with a warm close.

---

{content}`},{id:"community-rewrite-comment",name:"Rewrite Comment",label:"Rewrite",description:"Professional, constructive rewrite",category:"Compose",isDefault:!1,prompt:`Rewrite the comment below to be professional, concise, and constructive while keeping the original meaning intact.

Output ONLY:

**Variant A \u2013 Short & direct**
(1\u20132 sentences)

**Variant B \u2013 Collaborative tone**
(2\u20134 sentences, warmer)

---

{content}`},{id:"write-email-helper",name:"Email Helper",label:"Email",description:"Short professional email draft",category:"Compose",isDefault:!1,prompt:`Write a professional, friendly email using ONLY the context below.

Output ONLY these four blocks \u2014 nothing before or after:

**Subject**
[6\u201310 words]

**Body**
(120\u2013180 words, natural tone)

**Sign-off choices**
1. Best regards, [Name]
2. Thanks & best, [Name]
3. Looking forward, [Name]

**Meeting proposals** (if scheduling is needed, next 1\u20132 business days)
- [Day, time]
- [Alternative day, time]

---

{content}`}];chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:!0}).catch(t=>{console.error("[Synto] setPanelBehavior failed:",t)});chrome.runtime.onInstalled.addListener(async({reason:t})=>{if(t==="install")try{(await chrome.storage.sync.get(e.TEMPLATES))[e.TEMPLATES]||await chrome.storage.sync.set({[e.TEMPLATES]:n})}catch(i){console.error("[Synto] onInstalled seed failed:",i)}});

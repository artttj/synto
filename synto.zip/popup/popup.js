"use strict";(()=>{var W={EXTRACT_CONTENT:"EXTRACT_CONTENT",COPY_TO_CLIPBOARD:"COPY_TO_CLIPBOARD",GET_TEMPLATES:"GET_TEMPLATES",SAVE_TEMPLATES:"SAVE_TEMPLATES"},u={TEMPLATES:"apc_templates",SETTINGS:"apc_settings",OPENAI_KEY:"apc_openai_key",GROK_KEY:"apc_grok_key",GEMINI_KEY:"apc_gemini_key"},T=["Understand","Decide","Act","Compose"],q=new Set(["default-structured-brief","analyze-article","community-debate-map","default-clean","extract-key-questions","lifestyle-recipe-card","lifestyle-buy-decision"]),M=[{id:"eng-ticket-analysis",name:"Ticket Analysis",label:"Ticket",description:"Summary, criteria, risks, next steps",category:"Understand",isDefault:!1,prompt:`You are a senior product engineer. Analyze ONLY the ticket below \u2014 do not invent information. Produce a developer-ready implementation brief.

Output ONLY the following markdown structure \u2014 nothing before or after:

## Summary
One crisp sentence: what is requested and why it matters.

## Goals
- 1\u20133 must-achieve outcomes

## Acceptance Criteria
1. Numbered, specific, testable conditions

## Technical Approach
High-level plan: steps, affected modules/APIs/DB changes, external dependencies.

## Tasks
- Task \xB7 Role (dev/qa/ux) \xB7 Estimate (S/M/L/XL) \xB7 Dependencies

## Risks & Mitigations
- Risk \u2192 mitigation (top 3 only)

## Open Questions
- Clarifications needed from author or stakeholders

## Priority
Low / Medium / High / Critical \u2014 one-sentence rationale

---

Ticket: [{title}]({url})

{content}`},{id:"eng-pr-review",name:"PR Review",label:"Code Review",description:"Changes, concerns, approvals, status",category:"Understand",isDefault:!1,prompt:`You are an elite code reviewer. Analyze ONLY the PR content below. Produce a concise, actionable review brief.

Output ONLY this exact markdown structure \u2014 nothing before or after:

## Summary
One paragraph: what the PR actually does and its intent.

## Impacted Areas
- Key files / modules / systems changed

## Findings

**Bugs / Logic**
- Issue \xB7 Severity (critical/high/medium/low) \xB7 Suggested fix

**Security / Performance**
- Issue \xB7 Severity \xB7 Suggested fix

**Tests / Coverage**
- Issue \xB7 Severity \xB7 Suggested fix

**Style / Maintainability**
- Issue \xB7 Severity \xB7 Suggested fix

## Test Recommendations
- What needs verification, missing test cases, quick smoke steps

## Verdict
Approve as-is / Approve with changes / Major rework needed / Reject \u2014 one-sentence reason.

## Post-Merge Follow-ups
- Optional cleanups / tech-debt items

---

Source: [{title}]({url})

{content}`},{id:"understand-structured-brief",name:"Structured Brief",label:"Brief",description:"Topic, key points, conclusions, open questions",category:"Understand",isDefault:!0,prompt:`You are a senior content analyst. Create a tight briefing from ONLY the source below. Do not add external facts.

Output ONLY this structure \u2014 nothing before or after:

## TL;DR
One powerful sentence summary.

## Audience
Who this is written for (persona, role, experience level).

## Key Takeaways
- 3\u20135 sharp, memorable bullets

## Evidence & Context
- 3\u20135 strongest claims, quotes, or data points from the source

## Conclusions
What was resolved, concluded, or recommended? Write "None yet" if unclear.

## Open Questions
What remains unclear, unresolved, or worth challenging?

---

Source: [{title}]({url})

{content}`},{id:"decide-brief",name:"Decision Brief",label:"Decision",description:"Options, trade-offs, recommendation",category:"Decide",isDefault:!1,prompt:`You are a principal decision architect. Using ONLY the context below, produce a short, executive-ready decision document.

Output ONLY the markdown below \u2014 nothing before or after:

## Context
2\u20134 sentences of background.

## Decision
One clear sentence: what exactly needs to be chosen.

## Options Compared

**Option A: [name]**
- Pros
- Cons
- Effort / Cost
- Time-to-value

**Option B: [name]**
- Pros
- Cons
- Effort / Cost
- Time-to-value

## Evaluation Criteria
- Criterion 1 (weight if scored)
(4\u20136 total)

## Recommendation
Chosen option + 2-sentence rationale anchored to the criteria.

## Next Actions
1. Step \xB7 Owner \xB7 Due \xB7 Metric
(3\u20134 items)

---

Source: [{title}]({url})

{content}`},{id:"decide-feature-request",name:"Feature Request Analysis",label:"Feature",description:"Problem, trade-offs, alternatives",category:"Decide",isDefault:!1,prompt:`You are a senior product engineer specializing in requirements distillation. Analyze ONLY the feature request below.

Output ONLY this structure \u2014 nothing before or after:

## Core Problem
One sentence: the real user pain or goal.

## User Stories
- As a [role], I want [feature] so that [benefit]
(3\u20134 stories)

## Acceptance Criteria
1. Numbered, testable conditions

## Edge Cases & Non-Functional
- Important boundaries, performance, security, accessibility needs

## MVP Scope
- In: \u2026
- Out / Later: \u2026

## Effort Sketch
Frontend: S / M / L
Backend: S / M / L
Infra / Other: S / M / L

---

Source: [{title}]({url})

{content}`},{id:"eng-action-items",name:"Extract Actions",label:"Actions",description:"Actions, next steps, blockers",category:"Act",isDefault:!1,prompt:`Extract every concrete action item from the content below. Output ONLY a numbered list \u2014 no introduction, no extra sentences.

Format each item:
1. **Action**: clear verb phrase
   **Owner**: role or person (infer if not explicit)
   **Due**: date / ASAP / none
   **Priority**: High / Medium / Low
   **Evidence**: short quote supporting this action

---

Source: [{title}]({url})

{content}`},{id:"extract-risks-blockers",name:"Risks & Blockers",label:"Risks",description:"Risks, blockers, assumptions",category:"Act",isDefault:!1,prompt:`Identify the most important risks and blockers from the content below. Output ONLY up to 8 items in this exact format \u2014 nothing else:

- **Title**: short name
  **Description**: 1\u20132 sentences
  **Likelihood**: Low / Medium / High
  **Impact**: Low / Medium / High / Critical
  **Mitigation**: concrete next step
  **Owner**: who should handle this
  **Escalation**: if stalled after 3 days \u2192 who / how

---

Source: [{title}]({url})

{content}`},{id:"lifestyle-smart-choice",name:"Smart Choice",label:"Recommend",description:"Options, trade-offs, quick verdict",category:"Act",isDefault:!1,prompt:`Score and decide between the options in the content below. Use a weighted scorecard. Output ONLY this structure \u2014 nothing before or after:

## Criteria (total weight 100)
- Criterion 1 \u2013 weight %
(4\u20136 criteria)

## Scorecard
| Option | Crit 1 | Crit 2 | Crit 3 | Crit 4 | Total (weighted) |
|--------|--------|--------|--------|--------|------------------|
| \u2026      | \u2026      | \u2026      | \u2026      | \u2026      | \u2026                |

## Winner
[Option name] \u2014 two-sentence explanation why it leads.

## Communication Snippet
Two sentences to tell stakeholders: benefit + immediate next step.

---

{content}`},{id:"write-compose-answer",name:"Draft Reply",label:"Reply",description:"Direct reply to a question or request",category:"Compose",isDefault:!1,prompt:`Draft a short, professional-yet-friendly reply for Slack or email based ONLY on the context below. Max 5\u20136 sentences.

Output ONLY the reply body text \u2014 no labels, no extras.

Structure: Start with an acknowledgment. Then give a direct answer or next step. Then a clear call-to-action (action + owner + due if relevant). End with a warm close.

---

{content}`},{id:"community-rewrite-comment",name:"Rewrite Comment",label:"Rewrite",description:"Professional, constructive rewrite",category:"Compose",isDefault:!1,prompt:`Rewrite the comment below to be professional, concise, and constructive while keeping the original meaning intact.

Output ONLY:

**Variant A \u2013 Short & direct**
(1\u20132 sentences)

**Variant B \u2013 Collaborative tone**
(2\u20134 sentences, warmer)

---

{content}`},{id:"write-email-helper",name:"Email Helper",label:"Email",description:"Short professional email draft",category:"Compose",isDefault:!1,prompt:`Write a professional, friendly email using ONLY the context below.

Output ONLY these four blocks \u2014 nothing before or after:

**Subject**
[6\u201310 words]

**Body**
(120\u2013180 words, natural tone)

**Sign-off choices**
1. Best regards, [Name]
2. Thanks & best, [Name]
3. Looking forward, [Name]

**Meeting proposals** (if scheduling is needed, next 1\u20132 business days)
- [Day, time]
- [Alternative day, time]

---

{content}`}],C={GREEN:4e3,YELLOW:16e3,MODEL_LIMITS:{"gpt-4o-mini":128e3,"gemini-2.0-flash":1048576,"grok-3-mini":131072}};function F(e){return Math.ceil(e.length/4)}function V(e){return e<C.GREEN?"green":e<C.YELLOW?"yellow":"red"}async function E(){return(await chrome.storage.local.get(u.OPENAI_KEY))[u.OPENAI_KEY]??""}async function b(){return(await chrome.storage.local.get(u.GROK_KEY))[u.GROK_KEY]??""}async function L(){return(await chrome.storage.local.get(u.GEMINI_KEY))[u.GEMINI_KEY]??""}async function R(){let t=(await chrome.storage.local.get(u.TEMPLATES))[u.TEMPLATES];if(!t)return M;let r=new Map(M.map(c=>[c.id,c])),s=t.filter(c=>!q.has(c.id)).map(c=>{let d=r.get(c.id);return d?{...c,name:d.name,label:d.label,category:d.category,description:d.description}:c}),m=new Set(s.map(c=>c.id)),a=M.filter(c=>!m.has(c.id));return a.length>0?[...s,...a]:s}async function D(){return{defaultTemplateId:"understand-structured-brief",theme:"dark",llmProvider:"openai",...(await chrome.storage.sync.get(u.SETTINGS))[u.SETTINGS]}}async function N(e){let t=await D();await chrome.storage.sync.set({[u.SETTINGS]:{...t,...e}})}var j={openai:"gpt-4o-mini",gemini:"gemini-2.0-flash",grok:"grok-3-mini"},pe={openai:"Ask ChatGPT",gemini:"Ask Gemini",grok:"Ask Grok"},o={templates:[],selectedTemplateId:null,extracted:null,rawMarkdown:"",finalText:"",previewOpen:!0,previewTab:"content",chatStreaming:!1,chatHistory:[],llmProvider:"openai"};function k(){return pe[o.llmProvider]??"Ask AI"}var l=e=>document.getElementById(e),n={btnOptions:null,btnHelp:null,intentTabs:null,templateCards:null,errorMsg:null,tokenCount:null,tokenWarning:null,previewPanel:null,previewText:null,btnPreviewToggle:null,previewArrow:null,btnCopyMd:null,btnPreviewCopy:null,btnRefreshContent:null,btnProcess:null,chatPanel:null,chatNoKey:null,chatOptionsLink:null,chatMessages:null,chatInputRow:null,chatInput:null,btnChatSend:null};function z(){n.btnOptions=l("btn-options"),n.btnHelp=l("btn-help"),n.intentTabs=l("intent-tabs"),n.templateCards=l("template-cards"),n.errorMsg=l("error-msg"),n.tokenCount=l("token-count"),n.tokenWarning=l("token-warning"),n.previewPanel=l("preview-panel"),n.previewText=l("preview-text"),n.btnPreviewToggle=l("btn-preview-toggle"),n.previewArrow=l("preview-arrow"),n.btnCopyMd=l("btn-copy-md"),n.btnPreviewCopy=l("btn-preview-copy"),n.btnRefreshContent=l("btn-refresh-content"),n.btnProcess=l("btn-process"),n.chatPanel=l("chat-panel"),n.chatNoKey=l("chat-no-key"),n.chatOptionsLink=l("chat-options-link"),n.chatMessages=l("chat-messages"),n.chatInputRow=l("chat-input-row"),n.chatInput=l("chat-input"),n.btnChatSend=l("btn-chat-send")}function g(e){e?(n.errorMsg.textContent=e,n.errorMsg.classList.remove("hidden")):(n.errorMsg.classList.add("hidden"),n.errorMsg.textContent="")}function _(){let e=o.previewTab==="prompt";n.previewText.value=e?o.finalText:o.rawMarkdown,n.btnCopyMd.textContent=e?"Copy Prompt":"Copy Markdown"}function w(e){o.previewOpen=e,n.previewPanel.classList.toggle("collapsed",!e),n.previewArrow.textContent=e?"\u25B4":"\u25BE",n.btnPreviewToggle.setAttribute("aria-expanded",String(e))}function J(e){let t=F(e),r=o.extracted?.source??"";n.tokenCount.textContent=`~${t.toLocaleString()}${r?` \xB7 ${r}`:""}`,n.tokenCount.className=`token-count ${V(t)}`;let i=j[o.llmProvider],s=C.MODEL_LIMITS[i]??128e3;n.tokenWarning.classList.toggle("hidden",t<=s*.85)}async function X(e,t){try{await navigator.clipboard.writeText(e),ue(t)}catch(r){g(`Copy failed: ${r instanceof Error?r.message:String(r)}`)}}function ue(e){let t=e===n.btnCopyMd,r=t?e.textContent:null;e.classList.add("copy-success"),t&&(e.textContent="Copied!"),setTimeout(()=>{e.classList.remove("copy-success"),t&&r&&(e.textContent=r)},2e3)}function Q(){n.btnPreviewToggle.addEventListener("click",()=>{w(!o.previewOpen)}),document.querySelectorAll(".preview-tab").forEach(e=>{e.addEventListener("click",()=>{document.querySelectorAll(".preview-tab").forEach(t=>{t.classList.remove("active"),t.setAttribute("aria-selected","false")}),e.classList.add("active"),e.setAttribute("aria-selected","true"),o.previewTab=e.dataset.tab,_(),o.previewOpen||w(!0)})}),n.btnCopyMd.addEventListener("click",async()=>{let e=o.previewTab==="prompt"?o.finalText:o.rawMarkdown;e&&await X(e,n.btnCopyMd)}),n.btnPreviewCopy.addEventListener("click",async()=>{let e=o.previewTab==="prompt"?o.finalText:o.rawMarkdown;e&&await X(e,n.btnPreviewCopy)})}function me(e,t){let r=o.templates.find(s=>s.id===t);if(!r||!e)return"";let i=e.selection??e.content??"";return r.prompt.replace(/\{content\}/g,e.content??"").replace(/\{selection\}/g,i).replace(/\{title\}/g,e.title??"").replace(/\{url\}/g,e.url??"").replace(/\{excerpt\}/g,e.excerpt??"").replace(/\{byline\}/g,e.byline??"").replace(/\{siteName\}/g,e.siteName??"")}function O(){o.extracted&&(o.finalText=me(o.extracted,o.selectedTemplateId),J(o.finalText),n.btnCopyMd.disabled=!1,n.btnProcess.disabled=!1,_(),n.previewPanel.classList.contains("hidden")&&(n.previewPanel.classList.remove("hidden"),w(!0)))}var f=T[0],G={},A=null;function K(){let e=new Set(T),t=new Set;for(let r of o.templates)r.category&&!e.has(r.category)&&t.add(r.category);return[...T,...[...t].sort()]}function Z(e){return o.templates.filter(t=>t.category===e)}function ge(){if(o.selectedTemplateId){let r=o.templates.find(i=>i.id===o.selectedTemplateId);if(r?.category&&K().includes(r.category))return r.category}let e=localStorage.getItem("synto_intent"),t=K();return e&&t.includes(e)?e:t[0]??T[0]}function fe(e){let t=n.previewText;if(!t||n.previewPanel.classList.contains("hidden")){e();return}t.classList.add("fading"),setTimeout(()=>{e(),t.classList.remove("fading")},90)}function Y(){f=ge(),G[f]=o.selectedTemplateId??"",he(),ee()}function he(){let e=n.intentTabs;e.innerHTML="";for(let t of K()){let r=document.createElement("button");r.type="button",r.setAttribute("role","tab"),r.className="intent-tab"+(t===f?" active":""),r.setAttribute("aria-selected",String(t===f)),r.dataset.intent=t,r.textContent=t,e.appendChild(r)}}function ee(){let e=n.templateCards;e.innerHTML="";for(let t of Z(f)){let r=document.createElement("button");r.type="button",r.setAttribute("role","option"),r.setAttribute("aria-selected",String(t.id===o.selectedTemplateId)),r.setAttribute("tabindex",t.id===o.selectedTemplateId?"0":"-1"),r.setAttribute("aria-label",t.name),r.title=t.name,r.className="template-card"+(t.id===o.selectedTemplateId?" selected":""),r.dataset.id=t.id,r.textContent=t.label??t.name,e.appendChild(r)}}function ye(){let e=n.templateCards.querySelectorAll(".template-card");for(let t of e){let r=t.dataset.id===o.selectedTemplateId;t.classList.toggle("selected",r),t.setAttribute("aria-selected",String(r)),t.setAttribute("tabindex",r?"0":"-1")}}function we(){let e=n.intentTabs.querySelectorAll(".intent-tab");for(let t of e){let r=t.dataset.intent===f;t.classList.toggle("active",r),t.setAttribute("aria-selected",String(r))}}function ve(e){f=e,localStorage.setItem("synto_intent",e);let t=G[e]??localStorage.getItem("synto_intent_sel_"+e),r=Z(e),i=t&&r.find(s=>s.id===t)?t:r[0]?.id??null;i&&i!==o.selectedTemplateId&&(o.selectedTemplateId=i,N({defaultTemplateId:i}),O()),ee(),we()}function te(e){e!==o.selectedTemplateId&&(o.selectedTemplateId=e,G[f]=e,localStorage.setItem("synto_intent_sel_"+f,e),ye(),A!==null&&clearTimeout(A),A=setTimeout(()=>{N({defaultTemplateId:e}),fe(()=>O()),A=null},150))}function Te(e){let t=Array.from(n.templateCards.querySelectorAll(".template-card"));if(!t.length)return;let r=t.indexOf(document.activeElement);if(e.key==="ArrowRight"||e.key==="ArrowDown")e.preventDefault(),t[(r+1)%t.length].focus();else if(e.key==="ArrowLeft"||e.key==="ArrowUp")e.preventDefault(),t[(r-1+t.length)%t.length].focus();else if(e.key==="Enter"||e.key===" "){e.preventDefault();let i=document.activeElement;i.dataset.id&&te(i.dataset.id)}}function ne(){n.intentTabs.addEventListener("click",e=>{let t=e.target.closest(".intent-tab");t?.dataset.intent&&ve(t.dataset.intent)}),n.templateCards.addEventListener("click",e=>{let t=e.target.closest(".template-card");t?.dataset.id&&te(t.dataset.id)}),n.templateCards.addEventListener("keydown",Te)}var I="\uE000";function Ee(e){let t=e.trim(),r="";for(;t!==r;)r=t,t=t.replace(/^\d+\.\s+/,"").trim();return t||e}function re(e){let t=p=>p.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"),r=[],i=t(e).replace(/```(?:\w*)\n?([\s\S]*?)```/g,(p,v)=>(r.push(`<pre><code>${v.trimEnd()}</code></pre>`),`${I}CODE${r.length-1}${I}`)),s=p=>p.replace(/`([^`]+)`/g,"<code>$1</code>").replace(/\*\*([^*\n]+)\*\*/g,"<strong>$1</strong>").replace(/\*([^*\n]+)\*/g,"<em>$1</em>").replace(/__([^_\n]+)__/g,"<strong>$1</strong>").replace(/_([^_\n]+)_/g,"<em>$1</em>"),m=i.split(`
`),a=[],c=!1,d=!1,h=()=>{c&&(a.push("</ul>"),c=!1),d&&(a.push("</ol>"),d=!1)},y=new RegExp(`^${I}CODE(\\d+)${I}$`);for(let p of m){let v=y.exec(p.trim());if(v){h(),a.push(r[parseInt(v[1],10)]);continue}let P=/^[-*] (.+)$/.exec(p);if(P){d&&(a.push("</ol>"),d=!1),c||(a.push("<ul>"),c=!0),a.push(`<li>${s(P[1])}</li>`);continue}let $=/^(\d+)\. (.+)$/.exec(p);if($){c&&(a.push("</ul>"),c=!1),d||(a.push("<ol>"),d=!0);let de=Ee($[2]);a.push(`<li>${s(de)}</li>`);continue}h();let U=/^#{1,3} (.+)$/.exec(p);if(U){a.push(`<strong>${s(U[1])}</strong><br>`);continue}if(p.trim()===""){a.push("<br>");continue}a.push(`${s(p)}<br>`)}return h(),a.join("").replace(/(<br>){3,}/g,"<br><br>")}function x(e,t){let r=document.createElement("div");r.className=`chat-bubble-wrap ${e}`;let i=document.createElement("div");return i.className=`chat-bubble ${e}`,i.textContent=t,r.appendChild(i),n.chatMessages.appendChild(r),n.chatMessages.scrollTop=n.chatMessages.scrollHeight,i}function be(e,t){let r=e.parentElement;if(!r)return;let i=document.createElement("button");i.className="chat-bubble-copy",i.type="button",i.title="Copy response",i.setAttribute("aria-label","Copy response"),i.innerHTML=`
    <svg class="icon-copy" width="11" height="11" viewBox="0 0 24 24" fill="none"
         stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <rect x="9" y="9" width="13" height="13" rx="2"/>
      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
    </svg>
    <svg class="icon-check" width="11" height="11" viewBox="0 0 24 24" fill="none"
         stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="20 6 9 17 4 12"/>
    </svg>`,i.addEventListener("click",async()=>{try{await navigator.clipboard.writeText(t),i.classList.add("copy-success"),setTimeout(()=>i.classList.remove("copy-success"),2e3)}catch(s){g(`Copy failed: ${s instanceof Error?s.message:String(s)}`)}}),r.appendChild(i)}async function B(e,{url:t,model:r,key:i}){let s=await fetch(t,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${i}`},body:JSON.stringify({model:r,messages:o.chatHistory,stream:!0})});if(!s.ok){if(s.status===429){let h=s.headers.get("Retry-After"),y=h?` Retry after ${h}s.`:" Wait a moment and try again.";throw new Error(`Rate limited (429).${y}`)}let d=await s.json().catch(()=>({}));throw new Error(d.error?.message??`HTTP ${s.status}`)}let m="",a=s.body.getReader(),c=new TextDecoder;for(;;){let{done:d,value:h}=await a.read();if(d)break;for(let y of c.decode(h).split(`
`)){if(!y.startsWith("data: "))continue;let p=y.slice(6).trim();if(p==="[DONE]")break;try{let P=JSON.parse(p).choices?.[0]?.delta?.content??"";m+=P,e.textContent=m,n.chatMessages.scrollTop=n.chatMessages.scrollHeight}catch{}}}e.classList.remove("streaming"),e.innerHTML=re(m),o.chatHistory.push({role:"assistant",content:m}),be(e,m)}async function Le(e){let t=await E();if(!t)throw new Error("No OpenAI API key. Add it in Options.");await B(e,{url:"https://api.openai.com/v1/chat/completions",model:"gpt-4o-mini",key:t})}async function ke(e){let t=await L();if(!t)throw new Error("No Gemini API key. Add it in Options.");await B(e,{url:"https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",model:"gemini-2.0-flash",key:t})}async function xe(e){let t=await b();if(!t)throw new Error("No Grok API key. Add it in Options.");await B(e,{url:"https://api.x.ai/v1/chat/completions",model:"grok-3-mini",key:t})}async function ie(e){o.llmProvider==="gemini"?await ke(e):o.llmProvider==="grok"?await xe(e):await Le(e)}async function Se(){if(!o.finalText||o.chatStreaming)return;if(n.chatPanel.classList.remove("hidden"),w(!1),!await{openai:E,gemini:L,grok:b}[o.llmProvider]?.()){n.chatNoKey.classList.remove("hidden");return}n.chatNoKey.classList.add("hidden"),o.chatHistory.push({role:"user",content:o.finalText});let r=x("assistant","");r.classList.add("streaming"),o.chatStreaming=!0,n.btnProcess.disabled=!0,n.btnProcess.textContent="Asking\u2026",n.btnProcess.classList.add("loading");try{await ie(r),n.chatInputRow.classList.remove("hidden")}catch(i){(r.parentElement??r).remove(),o.chatHistory.pop(),x("error",`Error: ${i instanceof Error?i.message:String(i)}`)}finally{o.chatStreaming=!1,n.btnProcess.disabled=!1,n.btnProcess.textContent=k(),n.btnProcess.classList.remove("loading"),r.classList.remove("streaming")}}function se(e){e.style.height="auto",e.style.height=`${Math.min(e.scrollHeight,120)}px`}async function oe(){let e=n.chatInput.value.trim();if(!e||o.chatStreaming)return;n.chatInput.value="",se(n.chatInput),x("user",e),o.chatHistory.push({role:"user",content:e});let t=x("assistant","");t.classList.add("streaming"),o.chatStreaming=!0,n.btnChatSend.disabled=!0,n.btnProcess.disabled=!0;try{await ie(t)}catch(r){(t.parentElement??t).remove(),o.chatHistory.pop(),x("error",`Error: ${r instanceof Error?r.message:String(r)}`)}finally{o.chatStreaming=!1,n.btnChatSend.disabled=!1,n.btnProcess.disabled=!1,t.classList.remove("streaming"),n.chatInput.focus()}}function ae(){n.btnProcess.addEventListener("click",Se),n.chatInput.addEventListener("input",()=>{se(n.chatInput)}),n.chatInput.addEventListener("keydown",e=>{e.key==="Enter"&&!e.shiftKey&&(e.preventDefault(),oe())}),n.btnChatSend.addEventListener("click",oe)}function le(){document.addEventListener("keydown",e=>{!e.altKey||!e.shiftKey||e.key!=="Enter"||(e.preventDefault(),n.btnProcess.disabled||n.btnProcess.click())})}function H(){n.btnCopyMd.disabled=!0,n.btnProcess.disabled=!0}async function ce(e){let t=await chrome.tabs.sendMessage(e,{type:W.EXTRACT_CONTENT,mode:"markdown"});if(!t?.success)throw new Error(t?.error??"Extraction failed.");o.extracted=t,o.rawMarkdown=t.content,O()}async function S(){g(null),H(),n.previewPanel.classList.add("hidden"),o.chatHistory=[],n.chatInputRow.classList.add("hidden");let[e]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!e?.id||e.url?.startsWith("chrome://")||e.url?.startsWith("chrome-extension://")){g("Cannot extract from this page type. Navigate to a regular web page."),H();return}try{await ce(e.id)}catch(t){let r=t instanceof Error?t.message:String(t);if(r?.includes("Receiving end does not exist"))try{await chrome.scripting.executeScript({target:{tabId:e.id},files:["content/content.js"]}),await ce(e.id)}catch(i){g(i instanceof Error?i.message:String(i)),H()}else g(r),H()}}async function Pe(){z();let[e,t]=await Promise.all([R(),D()]);document.documentElement.dataset.theme=t.theme??"dark",o.templates=e,o.selectedTemplateId=t.defaultTemplateId??e[0]?.id??null,o.llmProvider=t.llmProvider??"openai",n.btnProcess.textContent=k(),Y(),ne(),Q(),ae(),le(),n.btnOptions.addEventListener("click",()=>{chrome.runtime.openOptionsPage()}),n.btnHelp.addEventListener("click",()=>{chrome.tabs.create({url:chrome.runtime.getURL("options/options.html")+"#help"})}),n.chatOptionsLink.addEventListener("click",s=>{s.preventDefault(),chrome.tabs.create({url:chrome.runtime.getURL("options/options.html#ai-connections")})}),n.btnRefreshContent.addEventListener("click",()=>{S()}),await S(),await{openai:E,gemini:L,grok:b}[o.llmProvider]?.()&&n.chatNoKey?.classList.add("hidden"),chrome.tabs.onActivated.addListener(()=>{S()}),chrome.tabs.onUpdated.addListener((s,m,a)=>{m.status==="complete"&&a.active&&S()}),chrome.storage.onChanged.addListener((s,m)=>{m==="local"&&s[u.TEMPLATES]&&R().then(a=>{o.templates=a,Y()}),s.llmProvider&&!o.chatStreaming&&(o.llmProvider=String(s.llmProvider.newValue??"openai"),n.btnProcess.textContent=k())})}Pe().catch(e=>{console.error("[Synto] Init failed:",e),g(`Initialization error: ${e instanceof Error?e.message:String(e)}`)});})();

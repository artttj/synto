"use strict";(()=>{var oe={EXTRACT_CONTENT:"EXTRACT_CONTENT",COPY_TO_CLIPBOARD:"COPY_TO_CLIPBOARD",GET_TEMPLATES:"GET_TEMPLATES",SAVE_TEMPLATES:"SAVE_TEMPLATES"},u={TEMPLATES:"apc_templates",SETTINGS:"apc_settings",OPENAI_KEY:"apc_openai_key",GROK_KEY:"apc_grok_key",GEMINI_KEY:"apc_gemini_key",HISTORY:"apc_history"};var x=["Understand","Decide","Act","Compose"],re=new Set(["default-structured-brief","analyze-article","community-debate-map","default-clean","extract-key-questions","lifestyle-recipe-card","lifestyle-buy-decision"]),D=[{id:"eng-ticket-analysis",name:"Ticket Analysis",label:"Ticket",description:"Summary, criteria, risks, next steps",category:"Understand",isDefault:!1,prompt:`You are a senior product engineer. Analyze ONLY the ticket below \u2014 do not invent information. Produce a developer-ready implementation brief.

Output ONLY the following markdown structure \u2014 nothing before or after:

## Summary
One crisp sentence: what is requested and why it matters.

## Goals
- 1\u20133 must-achieve outcomes

## Acceptance Criteria
1. Numbered, specific, testable conditions

## Technical Approach
High-level plan: steps, affected modules/APIs/DB changes, external dependencies.

## Tasks
- Task \xB7 Role (dev/qa/ux) \xB7 Estimate (S/M/L/XL) \xB7 Dependencies

## Risks & Mitigations
- Risk \u2192 mitigation (top 3 only)

## Open Questions
- Clarifications needed from author or stakeholders

## Priority
Low / Medium / High / Critical \u2014 one-sentence rationale

---

Ticket: [{title}]({url})

{content}`},{id:"eng-pr-review",name:"PR Review",label:"Code Review",description:"Changes, concerns, approvals, status",category:"Understand",isDefault:!1,prompt:`You are an elite code reviewer. Analyze ONLY the PR content below. Produce a concise, actionable review brief.

Output ONLY this exact markdown structure \u2014 nothing before or after:

## Summary
One paragraph: what the PR actually does and its intent.

## Impacted Areas
- Key files / modules / systems changed

## Findings

**Bugs / Logic**
- Issue \xB7 Severity (critical/high/medium/low) \xB7 Suggested fix

**Security / Performance**
- Issue \xB7 Severity \xB7 Suggested fix

**Tests / Coverage**
- Issue \xB7 Severity \xB7 Suggested fix

**Style / Maintainability**
- Issue \xB7 Severity \xB7 Suggested fix

## Test Recommendations
- What needs verification, missing test cases, quick smoke steps

## Verdict
Approve as-is / Approve with changes / Major rework needed / Reject \u2014 one-sentence reason.

## Post-Merge Follow-ups
- Optional cleanups / tech-debt items

---

Source: [{title}]({url})

{content}`},{id:"understand-structured-brief",name:"Structured Brief",label:"Brief",description:"Topic, key points, conclusions, open questions",category:"Understand",isDefault:!0,prompt:`You are a senior content analyst. Create a tight briefing from ONLY the source below. Do not add external facts.

Output ONLY this structure \u2014 nothing before or after:

## TL;DR
One powerful sentence summary.

## Audience
Who this is written for (persona, role, experience level).

## Key Takeaways
- 3\u20135 sharp, memorable bullets

## Evidence & Context
- 3\u20135 strongest claims, quotes, or data points from the source

## Conclusions
What was resolved, concluded, or recommended? Write "None yet" if unclear.

## Open Questions
What remains unclear, unresolved, or worth challenging?

---

Source: [{title}]({url})

{content}`},{id:"decide-brief",name:"Decision Brief",label:"Decision",description:"Options, trade-offs, recommendation",category:"Decide",isDefault:!1,prompt:`You're helping a friend decide. Read the content, figure out what it is, and respond accordingly.

If it's a movie, show, book, album, or anything creative: be a sharp critic. Pick a side \u2014 worth it or skip it. No hedging, no "it depends." Use "I" statements. Mediocre means no. End with a VERDICT that includes a star rating using \u2B50 and \u2606 and a score like 3.5/5.

If it's a restaurant, menu, or food: be a helpful friend who knows food. Point out the best dishes, flag healthy or light options, mention anything to avoid. No harsh criticism \u2014 just honest, useful picks. End with a VERDICT.

For anything else: make a clear call. Pick the best option and say why in two sentences. No sitting on the fence. End with a VERDICT.

Talk like a person. Short sentences. No jargon, no filler, no review clich\xE9s. Nothing before or after the analysis and VERDICT.

---

{content}`},{id:"decide-feature-request",name:"Feature Request Analysis",label:"Feature",description:"Problem, trade-offs, alternatives",category:"Decide",isDefault:!1,prompt:`You are a senior product engineer specializing in requirements distillation. Analyze ONLY the feature request below.

Output ONLY this structure \u2014 nothing before or after:

## Core Problem
One sentence: the real user pain or goal.

## User Stories
- As a [role], I want [feature] so that [benefit]
(3\u20134 stories)

## Acceptance Criteria
1. Numbered, testable conditions

## Edge Cases & Non-Functional
- Important boundaries, performance, security, accessibility needs

## MVP Scope
- In: \u2026
- Out / Later: \u2026

## Effort Sketch
Frontend: S / M / L
Backend: S / M / L
Infra / Other: S / M / L

---

Source: [{title}]({url})

{content}`},{id:"eng-action-items",name:"Extract Actions",label:"Actions",description:"Actions, next steps, blockers",category:"Act",isDefault:!1,prompt:`Extract every concrete action item from the content below. Output ONLY a numbered list \u2014 no introduction, no extra sentences.

Format each item:
1. **Action**: clear verb phrase
   **Owner**: role or person (infer if not explicit)
   **Due**: date / ASAP / none
   **Priority**: High / Medium / Low
   **Evidence**: short quote supporting this action

---

Source: [{title}]({url})

{content}`},{id:"extract-risks-blockers",name:"Risks & Blockers",label:"Risks",description:"Risks, blockers, assumptions",category:"Act",isDefault:!1,prompt:`Identify the most important risks and blockers from the content below. Output ONLY up to 8 items in this exact format \u2014 nothing else:

- **Title**: short name
  **Description**: 1\u20132 sentences
  **Likelihood**: Low / Medium / High
  **Impact**: Low / Medium / High / Critical
  **Mitigation**: concrete next step
  **Owner**: who should handle this
  **Escalation**: if stalled after 3 days \u2192 who / how

---

Source: [{title}]({url})

{content}`},{id:"lifestyle-smart-choice",name:"Smart Choice",label:"Recommend",description:"Options, trade-offs, quick verdict",category:"Act",isDefault:!1,prompt:`You're helping a friend pick the best option. Read the content, figure out what it is, and respond accordingly.

If it's a movie, show, book, album, or anything creative: be a sharp critic. Love it or hate it \u2014 no middle ground. Use "I" statements. Mediocre means no. End with a VERDICT that includes a star rating using \u2B50 and \u2606 and a score like 3.5/5.

If it's a restaurant menu or food: be a helpful advisor. Pick the best dishes, flag healthy and light options, call out anything worth skipping. Practical and direct \u2014 not harsh. End with a VERDICT.

For anything else: name the best option and say why. One clear pick, no hedging. End with a VERDICT.

Talk like a person. Short sentences. No jargon, no filler, no review clich\xE9s. Nothing before or after the analysis and VERDICT.

---

{content}`},{id:"write-compose-answer",name:"Draft Reply",label:"Reply",description:"Direct reply to a question or request",category:"Compose",isDefault:!1,prompt:`Draft a short, professional-yet-friendly reply for Slack or email based ONLY on the context below. Max 5\u20136 sentences.

Output ONLY the reply body text \u2014 no labels, no extras.

Structure: Start with an acknowledgment. Then give a direct answer or next step. Then a clear call-to-action (action + owner + due if relevant). End with a warm close.

---

{content}`},{id:"community-rewrite-comment",name:"Rewrite Comment",label:"Rewrite",description:"Professional, constructive rewrite",category:"Compose",isDefault:!1,prompt:`Rewrite the comment below to be professional, concise, and constructive while keeping the original meaning intact.

Output ONLY:

**Variant A \u2013 Short & direct**
(1\u20132 sentences)

**Variant B \u2013 Collaborative tone**
(2\u20134 sentences, warmer)

---

{content}`},{id:"write-email-helper",name:"Email Helper",label:"Email",description:"Short professional email draft",category:"Compose",isDefault:!1,prompt:`Write a professional, friendly email using ONLY the context below.

Output ONLY these four blocks \u2014 nothing before or after:

**Subject**
[6\u201310 words]

**Body**
(120\u2013180 words, natural tone)

**Sign-off choices**
1. Best regards, [Name]
2. Thanks & best, [Name]
3. Looking forward, [Name]

**Meeting proposals** (if scheduling is needed, next 1\u20132 business days)
- [Day, time]
- [Alternative day, time]

---

{content}`}],O={GREEN:4e3,YELLOW:16e3,MODEL_LIMITS:{"gpt-4o-mini":128e3,"gpt-4o":128e3,"o3-mini":2e5,"gemini-2.0-flash":1048576,"gemini-2.5-flash":1048576,"gemini-2.5-pro":2097152,"grok-3-mini":131072,"grok-3":131072}};function ie(e){return Math.ceil(e.length/4)}function se(e){return e<O.GREEN?"green":e<O.YELLOW?"yellow":"red"}async function P(){return(await chrome.storage.local.get(u.OPENAI_KEY))[u.OPENAI_KEY]??""}async function M(){return(await chrome.storage.local.get(u.GROK_KEY))[u.GROK_KEY]??""}async function A(){return(await chrome.storage.local.get(u.GEMINI_KEY))[u.GEMINI_KEY]??""}async function z(){let t=(await chrome.storage.local.get(u.TEMPLATES))[u.TEMPLATES];if(!t)return D;let r=new Map(D.map(a=>[a.id,a])),s=t.filter(a=>!re.has(a.id)).map(a=>{let l=r.get(a.id);return l?{...a,name:l.name,label:l.label,category:l.category,description:l.description}:a}),d=new Set(s.map(a=>a.id)),f=D.filter(a=>!d.has(a.id));return f.length>0?[...s,...f]:s}async function j(){let e=await chrome.storage.sync.get(u.SETTINGS);return{defaultTemplateId:"understand-structured-brief",theme:"dark",llmProvider:"openai",language:"en",systemPrompt:"",openaiModel:"gpt-4o-mini",geminiModel:"gemini-2.0-flash",grokModel:"grok-3-mini",pinnedTemplateIds:[],...e[u.SETTINGS]}}async function N(e){let t=await j();await chrome.storage.sync.set({[u.SETTINGS]:{...t,...e}})}function B(e){try{let t=new URL(e);t.hash="";let r=["utm_source","utm_medium","utm_campaign","utm_term","utm_content","fbclid","gclid","ref"];for(let i of r)t.searchParams.delete(i);return t.toString()}catch{return e}}async function ae(e){return((await chrome.storage.local.get(u.HISTORY))[u.HISTORY]??{})[e]??[]}async function le(e,t){let i=(await chrome.storage.local.get(u.HISTORY))[u.HISTORY]??{},s=i[e]??[];i[e]=[t,...s].slice(0,3);let d=Object.keys(i);if(d.length>40){let f=d.map(a=>({k:a,ts:i[a][0]?.ts??0})).sort((a,l)=>a.ts-l.ts);for(let a=0;a<d.length-40;a++)delete i[f[a].k]}await chrome.storage.local.set({[u.HISTORY]:i})}var He={popup_preview:"Preview",popup_content_tab:"Content",popup_prompt_tab:"Prompt",popup_refresh_content:"Refresh content",popup_near_limit:"Near limit",popup_chat_placeholder:"Ask a follow-up\u2026",popup_no_key_prefix:"No API key set. Add it in\xA0",popup_options_link:"Options",popup_no_key_suffix:".",popup_copy_markdown:"Copy Markdown",popup_copy_prompt:"Copy Prompt",popup_copied:"Copied!",popup_ask_chatgpt:"Ask ChatGPT",popup_ask_gemini:"Ask Gemini",popup_ask_grok:"Ask Grok",popup_ask_ai:"Ask AI",popup_asking:"Asking\u2026",popup_export_chat:"Export .md",popup_pin:"Pin template",popup_history_restore:"Previous conversation on this page",popup_history_yes:"Restore",popup_history_dismiss:"Dismiss",options_brand_sub:"Settings",options_nav_general:"General",options_nav_ai:"AI Connections",options_nav_library:"Prompt Library",options_nav_help:"Help",options_nav_about:"About",options_general_heading:"General",options_general_desc:"Configure default behaviour when the extension opens.",options_default_template:"Default Template",options_default_template_desc:"Pre-selected prompt when the popup opens",options_ai_provider:"AI Provider",options_ai_provider_desc:"Which service runs the analysis",options_theme:"Theme",options_theme_desc:"Interface colour scheme",options_theme_dark:"Dark",options_theme_light:"Light",options_language:"Language",options_language_desc:"Interface language",options_save:"Save Settings",options_saved:"\u2713 Saved",options_system_prompt:"System Prompt",options_system_prompt_desc:"Prepended to every request. Leave blank to skip.",options_system_prompt_placeholder:"You are a helpful assistant\u2026",options_ai_heading:"AI Connections",options_ai_desc:"API keys are stored locally on your device and are never transmitted by this extension.",options_library_heading:"Prompt Library",options_library_desc:"Browse, search, and manage your prompt templates.",options_search_placeholder:"Search templates\u2026",options_help_heading:"Help",options_help_desc:"How Synto works and keyboard shortcuts.",options_about_heading:"About Synto",options_builtin:"built-in",options_new_template:"New Template",options_new_template_title:"Add new template",options_edit_template:"Edit Template",options_new_category:"New category\u2026",options_delete:"Delete",options_edit:"Edit",options_cancel:"Cancel",options_save_template:"Save Template",options_template_name_placeholder:"Template name",options_template_prompt_placeholder:"Write your prompt here\u2026",options_delete_confirm:"Delete this template?",options_no_results:"No templates yet.",options_no_results_search:'No templates matching\xA0"{q}"',status_connected:"Connected",status_not_configured:"Not Configured",error_no_key_openai:"No OpenAI API key. Add it in Options.",error_no_key_gemini:"No Gemini API key. Add it in Options.",error_no_key_grok:"No Grok API key. Add it in Options.",category_understand:"Understand",category_decide:"Decide",category_act:"Act",category_compose:"Compose",category_custom:"Custom",category_pinned:"Pinned","template_label_eng-ticket-analysis":"Ticket","template_label_eng-pr-review":"Code Review","template_label_understand-structured-brief":"Brief","template_label_decide-brief":"Decision","template_label_decide-feature-request":"Feature","template_label_eng-action-items":"Actions","template_label_extract-risks-blockers":"Risks","template_label_lifestyle-smart-choice":"Recommend","template_label_write-compose-answer":"Reply","template_label_community-rewrite-comment":"Rewrite","template_label_write-email-helper":"Email","template_name_eng-ticket-analysis":"Ticket Analysis","template_name_eng-pr-review":"PR Review","template_name_understand-structured-brief":"Structured Brief","template_name_decide-brief":"Decision Brief","template_name_decide-feature-request":"Feature Request Analysis","template_name_eng-action-items":"Extract Actions","template_name_extract-risks-blockers":"Risks & Blockers","template_name_lifestyle-smart-choice":"Smart Choice","template_name_write-compose-answer":"Draft Reply","template_name_community-rewrite-comment":"Rewrite Comment","template_name_write-email-helper":"Email Helper"},K=He;var Re={popup_preview:"Vorschau",popup_content_tab:"Inhalt",popup_prompt_tab:"Prompt",popup_refresh_content:"Inhalt aktualisieren",popup_near_limit:"Fast am Limit",popup_chat_placeholder:"Nachfrage stellen\u2026",popup_no_key_prefix:"Kein API-Schl\xFCssel. In den\xA0",popup_options_link:"Einstellungen",popup_no_key_suffix:"\xA0hinzuf\xFCgen.",popup_copy_markdown:"Markdown kopieren",popup_copy_prompt:"Prompt kopieren",popup_copied:"Kopiert!",popup_ask_chatgpt:"ChatGPT fragen",popup_ask_gemini:"Gemini fragen",popup_ask_grok:"Grok fragen",popup_ask_ai:"KI fragen",popup_asking:"Anfrage l\xE4uft\u2026",popup_export_chat:"Als .md exportieren",popup_pin:"Template anpinnen",popup_history_restore:"Vorherige Unterhaltung auf dieser Seite",popup_history_yes:"Wiederherstellen",popup_history_dismiss:"Schlie\xDFen",options_brand_sub:"Einstellungen",options_nav_general:"Allgemein",options_nav_ai:"AI-Verbindungen",options_nav_library:"Prompt-Bibliothek",options_nav_help:"Hilfe",options_nav_about:"\xDCber",options_general_heading:"Allgemein",options_general_desc:"Standardverhalten beim \xD6ffnen der Erweiterung festlegen.",options_default_template:"Standard-Template",options_default_template_desc:"Vorausgew\xE4hlter Prompt beim \xD6ffnen",options_ai_provider:"AI-Anbieter",options_ai_provider_desc:"Welcher Dienst die Analyse durchf\xFChrt",options_theme:"Theme",options_theme_desc:"Farbschema der Oberfl\xE4che",options_theme_dark:"Dunkel",options_theme_light:"Hell",options_language:"Sprache",options_language_desc:"Sprache der Benutzeroberfl\xE4che",options_save:"Einstellungen speichern",options_saved:"\u2713 Gespeichert",options_system_prompt:"System-Prompt",options_system_prompt_desc:"Wird jeder Anfrage vorangestellt. Leer lassen zum \xDCberspringen.",options_system_prompt_placeholder:"Du bist ein hilfreicher Assistent\u2026",options_ai_heading:"AI-Verbindungen",options_ai_desc:"API-Schl\xFCssel werden lokal auf Ihrem Ger\xE4t gespeichert und nie \xFCbertragen.",options_library_heading:"Prompt-Bibliothek",options_library_desc:"Prompt-Templates durchsuchen und verwalten.",options_search_placeholder:"Templates suchen\u2026",options_help_heading:"Hilfe",options_help_desc:"So funktioniert Synto und Tastaturk\xFCrzel.",options_about_heading:"\xDCber Synto",options_builtin:"integriert",options_new_template:"Neues Template",options_new_template_title:"Neues Template hinzuf\xFCgen",options_edit_template:"Template bearbeiten",options_new_category:"Neue Kategorie\u2026",options_delete:"L\xF6schen",options_edit:"Bearbeiten",options_cancel:"Abbrechen",options_save_template:"Template speichern",options_template_name_placeholder:"Template-Name",options_template_prompt_placeholder:"Prompt hier eingeben\u2026",options_delete_confirm:"Dieses Template l\xF6schen?",options_no_results:"Keine Templates vorhanden.",options_no_results_search:'Keine Templates f\xFCr\xA0"{q}"',status_connected:"Verbunden",status_not_configured:"Nicht konfiguriert",error_no_key_openai:"Kein OpenAI API-Schl\xFCssel. Unter Einstellungen hinzuf\xFCgen.",error_no_key_gemini:"Kein Gemini API-Schl\xFCssel. Unter Einstellungen hinzuf\xFCgen.",error_no_key_grok:"Kein Grok API-Schl\xFCssel. Unter Einstellungen hinzuf\xFCgen.",category_understand:"Verstehen",category_decide:"Entscheiden",category_act:"Handeln",category_compose:"Verfassen",category_custom:"Benutzerdefiniert",category_pinned:"Angeheftet","template_label_eng-ticket-analysis":"Ticket","template_label_eng-pr-review":"Code Review","template_label_understand-structured-brief":"Briefing","template_label_decide-brief":"Entscheidung","template_label_decide-feature-request":"Feature","template_label_eng-action-items":"Aktionen","template_label_extract-risks-blockers":"Risiken","template_label_lifestyle-smart-choice":"Empfehlung","template_label_write-compose-answer":"Antwort","template_label_community-rewrite-comment":"Umschreiben","template_label_write-email-helper":"E-Mail","template_name_eng-ticket-analysis":"Ticket-Analyse","template_name_eng-pr-review":"PR Review","template_name_understand-structured-brief":"Strukturiertes Briefing","template_name_decide-brief":"Entscheidungshilfe","template_name_decide-feature-request":"Feature-Anfrage-Analyse","template_name_eng-action-items":"Aktionen extrahieren","template_name_extract-risks-blockers":"Risiken & Blocker","template_name_lifestyle-smart-choice":"Beste Wahl","template_name_write-compose-answer":"Antwort entwerfen","template_name_community-rewrite-comment":"Kommentar umschreiben","template_name_write-email-helper":"E-Mail-Assistent"},ce=Re;var pe=K;function de(e){pe=e==="de"?ce:K}function p(e){return pe[e]??K[e]??e}function me(e=document){e.querySelectorAll("[data-i18n]").forEach(t=>{t.textContent=p(t.getAttribute("data-i18n"))}),e.querySelectorAll("[data-i18n-placeholder]").forEach(t=>{t.setAttribute("placeholder",p(t.getAttribute("data-i18n-placeholder")))}),e.querySelectorAll("[data-i18n-title]").forEach(t=>{t.setAttribute("title",p(t.getAttribute("data-i18n-title")))})}var F={openai:"gpt-4o-mini",gemini:"gemini-2.0-flash",grok:"grok-3-mini"},Oe={openai:"popup_ask_chatgpt",gemini:"popup_ask_gemini",grok:"popup_ask_grok"},o={templates:[],selectedTemplateId:null,extracted:null,rawMarkdown:"",finalText:"",previewOpen:!0,previewTab:"content",chatStreaming:!1,chatHistory:[],llmProvider:"openai",systemPrompt:"",openaiModel:F.openai,geminiModel:F.gemini,grokModel:F.grok,pinnedIds:[]};function S(){return o.llmProvider==="gemini"?o.geminiModel:o.llmProvider==="grok"?o.grokModel:o.openaiModel}function I(){let e=Oe[o.llmProvider];return e?p(e):p("popup_ask_ai")}var c=e=>document.getElementById(e),n={btnOptions:null,btnHelp:null,intentTabs:null,templateCards:null,errorMsg:null,tokenCount:null,tokenWarning:null,previewPanel:null,previewText:null,btnPreviewToggle:null,previewArrow:null,btnCopyMd:null,btnPreviewCopy:null,btnRefreshContent:null,btnProcess:null,chatPanel:null,chatNoKey:null,chatOptionsLink:null,chatMessages:null,chatInputRow:null,chatInput:null,btnChatSend:null,chatExportRow:null,btnExportChat:null,chatHistoryBanner:null,chatHistoryLabel:null,btnHistoryRestore:null,btnHistoryDismiss:null};function ue(){n.btnOptions=c("btn-options"),n.btnHelp=c("btn-help"),n.intentTabs=c("intent-tabs"),n.templateCards=c("template-cards"),n.errorMsg=c("error-msg"),n.tokenCount=c("token-count"),n.tokenWarning=c("token-warning"),n.previewPanel=c("preview-panel"),n.previewText=c("preview-text"),n.btnPreviewToggle=c("btn-preview-toggle"),n.previewArrow=c("preview-arrow"),n.btnCopyMd=c("btn-copy-md"),n.btnPreviewCopy=c("btn-preview-copy"),n.btnRefreshContent=c("btn-refresh-content"),n.btnProcess=c("btn-process"),n.chatPanel=c("chat-panel"),n.chatNoKey=c("chat-no-key"),n.chatOptionsLink=c("chat-options-link"),n.chatMessages=c("chat-messages"),n.chatInputRow=c("chat-input-row"),n.chatInput=c("chat-input"),n.btnChatSend=c("btn-chat-send"),n.chatExportRow=c("chat-export-row"),n.btnExportChat=c("btn-export-chat"),n.chatHistoryBanner=c("chat-history-banner"),n.chatHistoryLabel=c("chat-history-label"),n.btnHistoryRestore=c("btn-history-restore"),n.btnHistoryDismiss=c("btn-history-dismiss")}function _(e){e?(n.errorMsg.textContent=e,n.errorMsg.classList.remove("hidden")):(n.errorMsg.classList.add("hidden"),n.errorMsg.textContent="")}function X(){let e=o.previewTab==="prompt";n.previewText.value=e?o.finalText:o.rawMarkdown,n.btnCopyMd.textContent=e?p("popup_copy_prompt"):p("popup_copy_markdown")}function E(e){o.previewOpen=e,n.previewPanel.classList.toggle("collapsed",!e),n.previewArrow.textContent=e?"\u25B4":"\u25BE",n.btnPreviewToggle.setAttribute("aria-expanded",String(e))}function he(e){let t=ie(e);n.tokenCount.textContent=`~${t.toLocaleString()}`,n.tokenCount.className=`token-count ${se(t)}`;let r=S(),i=O.MODEL_LIMITS[r]??128e3;n.tokenWarning.classList.toggle("hidden",t<=i*.85)}async function ge(e,t){try{await navigator.clipboard.writeText(e),De(t)}catch(r){_(`Copy failed: ${r instanceof Error?r.message:String(r)}`)}}function De(e){let t=e===n.btnCopyMd,r=t?e.textContent:null;e.classList.add("copy-success"),t&&(e.textContent=p("popup_copied")),setTimeout(()=>{e.classList.remove("copy-success"),t&&r&&(e.textContent=r)},2e3)}function fe(){n.btnPreviewToggle.addEventListener("click",()=>{E(!o.previewOpen)}),document.querySelectorAll(".preview-tab").forEach(e=>{e.addEventListener("click",()=>{document.querySelectorAll(".preview-tab").forEach(t=>{t.classList.remove("active"),t.setAttribute("aria-selected","false")}),e.classList.add("active"),e.setAttribute("aria-selected","true"),o.previewTab=e.dataset.tab,X(),o.previewOpen||E(!0)})}),n.btnCopyMd.addEventListener("click",async()=>{let e=o.previewTab==="prompt"?o.finalText:o.rawMarkdown;e&&await ge(e,n.btnCopyMd)}),n.btnPreviewCopy.addEventListener("click",async()=>{let e=o.previewTab==="prompt"?o.finalText:o.rawMarkdown;e&&await ge(e,n.btnPreviewCopy)})}var Q="__pinned__";function Ne(e,t){let r=o.templates.find(s=>s.id===t);if(!r||!e)return"";let i=e.selection??e.content??"";return r.prompt.replace(/\{content\}/g,e.content??"").replace(/\{selection\}/g,i).replace(/\{title\}/g,e.title??"").replace(/\{url\}/g,e.url??"").replace(/\{siteName\}/g,e.siteName??"")}function G(){o.extracted&&(o.finalText=Ne(o.extracted,o.selectedTemplateId),he(o.finalText),n.btnCopyMd.disabled=!1,n.btnProcess.disabled=!1,X(),n.previewPanel.classList.contains("hidden")&&(n.previewPanel.classList.remove("hidden"),E(!0)))}var b=x[0],Z={},$=null;function J(){let e=new Set(x),t=new Set;for(let i of o.templates)i.category&&!e.has(i.category)&&t.add(i.category);let r=[...x,...[...t].sort()];return o.pinnedIds.length>0&&r.unshift(Q),r}function _e(e){if(e===Q)return o.pinnedIds.map(r=>o.templates.find(i=>i.id===r)).filter(r=>r!==void 0);let t=o.templates.filter(r=>r.category===e);return t.sort((r,i)=>{let s=o.pinnedIds.includes(r.id)?0:1,d=o.pinnedIds.includes(i.id)?0:1;return s-d}),t}function Be(){if(o.selectedTemplateId){let r=o.templates.find(i=>i.id===o.selectedTemplateId);if(r?.category&&J().includes(r.category))return r.category}let e=localStorage.getItem("synto_intent"),t=J();return e&&t.includes(e)?e:t[0]??x[0]}function Ke(e){let t=n.previewText;if(!t||n.previewPanel.classList.contains("hidden")){e();return}t.classList.add("fading"),setTimeout(()=>{e(),t.classList.remove("fading")},90)}function Y(){b=Be(),Z[b]=o.selectedTemplateId??"",$e(),ye()}function $e(){let e=n.intentTabs;e.innerHTML="";for(let t of J()){let r=document.createElement("button");r.type="button",r.setAttribute("role","tab"),r.className="intent-tab"+(t===b?" active":""),r.setAttribute("aria-selected",String(t===b)),r.dataset.intent=t,t===Q?r.textContent=p("category_pinned")||"Pinned":r.textContent=p("category_"+t.toLowerCase())||t,e.appendChild(r)}}function Ge(e){let t=o.pinnedIds.includes(e),r=document.createElement("button");return r.type="button",r.className="card-pin-btn"+(t?" pinned":""),r.title=p("popup_pin")||"Pin template",r.setAttribute("aria-label",p("popup_pin")||"Pin template"),r.setAttribute("aria-pressed",String(t)),r.innerHTML=t?'<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>':'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>',r}function ye(){let e=n.templateCards;e.innerHTML="";for(let t of _e(b)){let r=p("template_label_"+t.id)||t.label||t.name,i=p("template_name_"+t.id)||t.name,s=document.createElement("button");s.type="button",s.setAttribute("role","option"),s.setAttribute("aria-selected",String(t.id===o.selectedTemplateId)),s.setAttribute("tabindex",t.id===o.selectedTemplateId?"0":"-1"),s.setAttribute("aria-label",i),s.title=i,s.className="template-card"+(t.id===o.selectedTemplateId?" selected":""),s.dataset.id=t.id,s.textContent=r;let d=Ge(t.id);s.appendChild(d),e.appendChild(s)}}function Ye(){let e=n.templateCards.querySelectorAll(".template-card");for(let t of e){let r=t.dataset.id===o.selectedTemplateId;t.classList.toggle("selected",r),t.setAttribute("aria-selected",String(r)),t.setAttribute("tabindex",r?"0":"-1")}}function Ue(){let e=n.intentTabs.querySelectorAll(".intent-tab");for(let t of e){let r=t.dataset.intent===b;t.classList.toggle("active",r),t.setAttribute("aria-selected",String(r))}}function qe(e){b=e,localStorage.setItem("synto_intent",e);let t=Z[e]??localStorage.getItem("synto_intent_sel_"+e),r=_e(e),i=t&&r.find(s=>s.id===t)?t:r[0]?.id??null;i&&i!==o.selectedTemplateId&&(o.selectedTemplateId=i,N({defaultTemplateId:i}),G()),ye(),Ue()}function be(e){e!==o.selectedTemplateId&&(o.selectedTemplateId=e,Z[b]=e,localStorage.setItem("synto_intent_sel_"+b,e),Ye(),$!==null&&clearTimeout($),$=setTimeout(()=>{N({defaultTemplateId:e}),Ke(()=>G()),$=null},150))}function We(e){let t=Array.from(n.templateCards.querySelectorAll(".template-card"));if(!t.length)return;let r=t.indexOf(document.activeElement);if(e.key==="ArrowRight"||e.key==="ArrowDown")e.preventDefault(),t[(r+1)%t.length].focus();else if(e.key==="ArrowLeft"||e.key==="ArrowUp")e.preventDefault(),t[(r-1+t.length)%t.length].focus();else if(e.key==="Enter"||e.key===" "){e.preventDefault();let i=document.activeElement;i.dataset.id&&be(i.dataset.id)}}function Ve(e){o.pinnedIds.indexOf(e)===-1?o.pinnedIds=[...o.pinnedIds,e]:o.pinnedIds=o.pinnedIds.filter(r=>r!==e),N({pinnedTemplateIds:o.pinnedIds}),Y()}function ve(){n.intentTabs.addEventListener("click",e=>{let t=e.target.closest(".intent-tab");t?.dataset.intent&&qe(t.dataset.intent)}),n.templateCards.addEventListener("click",e=>{let t=e.target.closest(".card-pin-btn");if(t){e.stopPropagation();let i=t.closest(".template-card");i?.dataset.id&&Ve(i.dataset.id);return}let r=e.target.closest(".template-card");r?.dataset.id&&be(r.dataset.id)}),n.templateCards.addEventListener("keydown",We)}var U="\uE000";function ze(e){let t=e.trim(),r="";for(;t!==r;)r=t,t=t.replace(/^\d+\.\s+/,"").trim();return t||e}function ee(e){let t=g=>g.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"),r=[],i=t(e).replace(/```(?:\w*)\n?([\s\S]*?)```/g,(g,w)=>(r.push(`<pre><code>${w.trimEnd()}</code></pre>`),`${U}CODE${r.length-1}${U}`)),s=g=>g.replace(/`([^`]+)`/g,"<code>$1</code>").replace(/\*\*([^*\n]+)\*\*/g,"<strong>$1</strong>").replace(/\*([^*\n]+)\*/g,"<em>$1</em>").replace(/__([^_\n]+)__/g,"<strong>$1</strong>").replace(/_([^_\n]+)_/g,"<em>$1</em>"),d=g=>{let w=y=>y.replace(/^\||\|$/g,"").split("|").map(ne=>ne.trim()),H=y=>/^\|?[\s|:-]+\|?$/.test(y)&&y.includes("-"),L=g.findIndex(H);if(L<1)return g.map(y=>`${s(y)}<br>`).join("");let R=w(g[0]),V=g.slice(L+1),Se=R.map(y=>`<th>${s(y)}</th>`).join(""),Ie=V.map(y=>`<tr>${w(y).map(Ce=>`<td>${s(Ce)}</td>`).join("")}</tr>`).join("");return`<div class="md-table-wrap"><table class="md-table"><thead><tr>${Se}</tr></thead><tbody>${Ie}</tbody></table></div>`},f=i.split(`
`),a=[],l=!1,m=!1,h=[],v=()=>{l&&(a.push("</ul>"),l=!1),m&&(a.push("</ol>"),m=!1)},C=()=>{h.length&&(a.push(d(h)),h=[])},W=new RegExp(`^${U}CODE(\\d+)${U}$`);for(let g of f){let w=W.exec(g.trim());if(w){C(),v(),a.push(r[parseInt(w[1],10)]);continue}if(/^\|.+/.test(g)){v(),h.push(g);continue}C();let H=/^[-*] (.+)$/.exec(g);if(H){m&&(a.push("</ol>"),m=!1),l||(a.push("<ul>"),l=!0),a.push(`<li>${s(H[1])}</li>`);continue}let L=/^(\d+)\. (.+)$/.exec(g);if(L){l&&(a.push("</ul>"),l=!1),m||(a.push("<ol>"),m=!0);let V=ze(L[2]);a.push(`<li>${s(V)}</li>`);continue}v();let R=/^#{1,3} (.+)$/.exec(g);if(R){a.push(`<strong>${s(R[1])}</strong><br>`);continue}if(g.trim()===""){!l&&!m&&a.push("<br>");continue}a.push(`${s(g)}<br>`)}return C(),v(),a.join("").replace(/(<br>){3,}/g,"<br><br>")}function k(e,t){let r=document.createElement("div");r.className=`chat-bubble-wrap ${e}`;let i=document.createElement("div");return i.className=`chat-bubble ${e}`,i.textContent=t,r.appendChild(i),n.chatMessages.appendChild(r),n.chatMessages.scrollTop=n.chatMessages.scrollHeight,i}function Ee(e,t){let r=e.parentElement;if(!r)return;let i=document.createElement("button");i.className="chat-bubble-copy",i.type="button",i.title="Copy response",i.setAttribute("aria-label","Copy response"),i.innerHTML=`
    <svg class="icon-copy" width="11" height="11" viewBox="0 0 24 24" fill="none"
         stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <rect x="9" y="9" width="13" height="13" rx="2"/>
      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
    </svg>
    <svg class="icon-check" width="11" height="11" viewBox="0 0 24 24" fill="none"
         stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="20 6 9 17 4 12"/>
    </svg>`,i.addEventListener("click",async()=>{try{await navigator.clipboard.writeText(t),i.classList.add("copy-success"),setTimeout(()=>i.classList.remove("copy-success"),2e3)}catch(s){_(`Copy failed: ${s instanceof Error?s.message:String(s)}`)}}),r.appendChild(i)}async function te(e,{url:t,model:r,key:i}){let s=await fetch(t,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${i}`},body:JSON.stringify({model:r,messages:o.chatHistory,stream:!0})});if(!s.ok){if(s.status===429){let m=s.headers.get("Retry-After"),h=m?` Retry after ${m}s.`:" Wait a moment and try again.";throw new Error(`Rate limited (429).${h}`)}let l=await s.json().catch(()=>({}));throw new Error(l.error?.message??`HTTP ${s.status}`)}let d="",f=s.body.getReader(),a=new TextDecoder;for(;;){let{done:l,value:m}=await f.read();if(l)break;for(let h of a.decode(m).split(`
`)){if(!h.startsWith("data: "))continue;let v=h.slice(6).trim();if(v==="[DONE]")break;try{let W=JSON.parse(v).choices?.[0]?.delta?.content??"";d+=W,e.textContent=d,n.chatMessages.scrollTop=n.chatMessages.scrollHeight}catch{}}}e.classList.remove("streaming"),e.innerHTML=ee(d),o.chatHistory.push({role:"assistant",content:d}),Ee(e,d)}async function je(e){let t=await P();if(!t)throw new Error(p("error_no_key_openai"));await te(e,{url:"https://api.openai.com/v1/chat/completions",model:o.openaiModel,key:t})}async function Fe(e){let t=await A();if(!t)throw new Error(p("error_no_key_gemini"));await te(e,{url:"https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",model:o.geminiModel,key:t})}async function Xe(e){let t=await M();if(!t)throw new Error(p("error_no_key_grok"));await te(e,{url:"https://api.x.ai/v1/chat/completions",model:o.grokModel,key:t})}async function Te(e){o.llmProvider==="gemini"?await Fe(e):o.llmProvider==="grok"?await Xe(e):await je(e)}async function ke(){let e=o.extracted?.url;!e||!o.selectedTemplateId||await le(B(e),{ts:Date.now(),templateId:o.selectedTemplateId,provider:o.llmProvider,model:S(),messages:o.chatHistory})}async function Je(){if(!o.finalText||o.chatStreaming)return;if(n.chatPanel.classList.remove("hidden"),E(!1),!await{openai:P,gemini:A,grok:M}[o.llmProvider]?.()){n.chatNoKey.classList.remove("hidden");return}n.chatNoKey.classList.add("hidden"),o.systemPrompt&&o.chatHistory.length===0&&o.chatHistory.unshift({role:"system",content:o.systemPrompt}),o.chatHistory.push({role:"user",content:o.finalText});let r=k("assistant","");r.classList.add("streaming"),o.chatStreaming=!0,n.btnProcess.disabled=!0,n.btnProcess.textContent=p("popup_asking"),n.btnProcess.classList.add("loading");try{await Te(r),n.chatInputRow.classList.remove("hidden"),n.chatExportRow.classList.remove("hidden"),n.chatHistoryBanner.classList.add("hidden"),ke()}catch(i){(r.parentElement??r).remove(),o.chatHistory.pop(),k("error",`Error: ${i instanceof Error?i.message:String(i)}`)}finally{o.chatStreaming=!1,n.btnProcess.disabled=!1,n.btnProcess.textContent=I(),n.btnProcess.classList.remove("loading"),r.classList.remove("streaming")}}function Le(e){e.style.height="auto",e.style.height=`${Math.min(e.scrollHeight,120)}px`}async function we(){let e=n.chatInput.value.trim();if(!e||o.chatStreaming)return;n.chatInput.value="",Le(n.chatInput),k("user",e),o.chatHistory.push({role:"user",content:e});let t=k("assistant","");t.classList.add("streaming"),o.chatStreaming=!0,n.btnChatSend.disabled=!0,n.btnProcess.disabled=!0;try{await Te(t),ke()}catch(r){(t.parentElement??t).remove(),o.chatHistory.pop(),k("error",`Error: ${r instanceof Error?r.message:String(r)}`)}finally{o.chatStreaming=!1,n.btnChatSend.disabled=!1,n.btnProcess.disabled=!1,t.classList.remove("streaming"),n.chatInput.focus()}}function xe(e){n.chatPanel.classList.remove("hidden"),n.chatHistoryBanner.classList.add("hidden"),n.chatMessages.innerHTML="";for(let t of e){if(t.role==="system")continue;let r=k(t.role,"");r.innerHTML=t.role==="assistant"?ee(t.content):"",t.role!=="assistant"&&(r.textContent=t.content),t.role==="assistant"&&Ee(r,t.content)}o.chatHistory=e,n.chatInputRow.classList.remove("hidden"),n.chatExportRow.classList.remove("hidden"),E(!1)}function Qe(){let e=o.chatHistory.filter(l=>l.role!=="system");if(!e.length)return;let t=new Date().toISOString(),r=t.slice(0,10),i=S(),s=[`# ${o.extracted?.title||"Chat export"}`,o.extracted?.url??"",`${t} \xB7 ${o.llmProvider} \xB7 ${i}`,o.selectedTemplateId?`Template: ${o.selectedTemplateId}`:"","","---",""];for(let l of e){let m=l.role==="user"?"**You:**":"**AI:**";s.push(`${m}

${l.content}`,"","---","")}let d=new Blob([s.join(`
`)],{type:"text/markdown"}),f=(o.extracted?.title||"chat").toLowerCase().replace(/[^a-z0-9]+/g,"-").slice(0,40),a=document.createElement("a");a.href=URL.createObjectURL(d),a.download=`${f}-${r}.md`,a.click(),URL.revokeObjectURL(a.href)}function Pe(){n.btnProcess.addEventListener("click",Je),n.chatInput.addEventListener("input",()=>{Le(n.chatInput)}),n.chatInput.addEventListener("keydown",e=>{e.key==="Enter"&&!e.shiftKey&&(e.preventDefault(),we())}),n.btnChatSend.addEventListener("click",we),n.btnExportChat.addEventListener("click",Qe)}function q(){n.btnCopyMd.disabled=!0,n.btnProcess.disabled=!0}async function Me(e){let t=await chrome.tabs.sendMessage(e,{type:oe.EXTRACT_CONTENT,mode:"markdown"});if(!t?.success)throw new Error(t?.error??"Extraction failed.");o.extracted=t,o.rawMarkdown=t.content,G()}async function T(){_(null),q(),n.previewPanel.classList.add("hidden"),o.chatHistory=[],n.chatInputRow.classList.add("hidden"),n.chatExportRow.classList.add("hidden"),n.chatHistoryBanner.classList.add("hidden");let[e]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!e?.id||e.url?.startsWith("chrome://")||e.url?.startsWith("chrome-extension://")){_("Cannot extract from this page type. Navigate to a regular web page."),q();return}try{await Me(e.id)}catch(t){let r=t instanceof Error?t.message:String(t);if(r?.includes("Receiving end does not exist"))try{await chrome.scripting.executeScript({target:{tabId:e.id},files:["content/content.js"]}),await Me(e.id)}catch(i){_(i instanceof Error?i.message:String(i)),q()}else _(r),q()}}function Ae(){document.addEventListener("keydown",e=>{!e.altKey||!e.shiftKey||e.key!=="Enter"||(e.preventDefault(),n.btnProcess.disabled||n.btnProcess.click())}),document.addEventListener("keydown",e=>{if(!(e.key==="a"||e.key==="A")||!(e.ctrlKey||e.metaKey))return;let t=e.target;t.tagName==="INPUT"||t.isContentEditable||t.tagName==="TEXTAREA"&&!t.readOnly||(e.preventDefault(),T())})}async function Ze(){ue();let[e,t]=await Promise.all([z(),j()]);de(t.language??"en"),me(),document.documentElement.dataset.theme=t.theme??"dark",o.templates=e,o.selectedTemplateId=t.defaultTemplateId??e[0]?.id??null,o.llmProvider=t.llmProvider??"openai",o.systemPrompt=t.systemPrompt,o.openaiModel=t.openaiModel,o.geminiModel=t.geminiModel,o.grokModel=t.grokModel,o.pinnedIds=t.pinnedTemplateIds,n.btnProcess.textContent=I(),Y(),ve(),fe(),Pe(),Ae(),n.btnOptions.addEventListener("click",()=>{chrome.runtime.openOptionsPage()}),n.btnHelp.addEventListener("click",()=>{chrome.tabs.create({url:chrome.runtime.getURL("options/options.html")+"#help"})}),n.chatOptionsLink.addEventListener("click",l=>{l.preventDefault(),chrome.tabs.create({url:chrome.runtime.getURL("options/options.html#ai-connections")})}),n.btnRefreshContent.addEventListener("click",()=>{T()});let r=document.getElementById("btn-content-info"),i=document.getElementById("content-info-popover"),s=navigator.platform.startsWith("Mac")?"\u2318A":"Ctrl+A";i.textContent=`Content not fully loaded? Press ${s} to re-extract.`,r.addEventListener("click",l=>{l.stopPropagation(),i.classList.toggle("hidden")}),document.addEventListener("click",()=>{i.classList.add("hidden")}),await T();let d=o.extracted?.url;if(d){let l=await ae(B(d));if(l.length>0){let m=l[0],h=new Date(m.ts).toLocaleDateString();n.chatPanel.classList.remove("hidden"),n.chatHistoryBanner.classList.remove("hidden"),n.chatHistoryLabel&&(n.chatHistoryLabel.textContent=`${p("popup_history_restore")} \u2014 ${h}`),n.btnHistoryRestore.addEventListener("click",()=>{xe(m.messages)}),n.btnHistoryDismiss.addEventListener("click",()=>{n.chatHistoryBanner.classList.add("hidden"),n.chatPanel.classList.add("hidden")})}}await{openai:P,gemini:A,grok:M}[o.llmProvider]?.()&&n.chatNoKey?.classList.add("hidden"),chrome.tabs.onActivated.addListener(()=>{T()}),chrome.tabs.onUpdated.addListener((l,m,h)=>{m.status==="complete"&&h.active&&T()}),chrome.storage.onChanged.addListener((l,m)=>{m==="local"&&l[u.TEMPLATES]&&z().then(h=>{o.templates=h,Y()}),l.llmProvider&&!o.chatStreaming&&(o.llmProvider=String(l.llmProvider.newValue??"openai"),n.btnProcess.textContent=I())})}Ze().catch(e=>{console.error("[Synto] Init failed:",e),_(`Initialization error: ${e instanceof Error?e.message:String(e)}`)});})();

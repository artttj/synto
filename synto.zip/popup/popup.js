"use strict";(()=>{var Q={EXTRACT_CONTENT:"EXTRACT_CONTENT",COPY_TO_CLIPBOARD:"COPY_TO_CLIPBOARD",GET_TEMPLATES:"GET_TEMPLATES",SAVE_TEMPLATES:"SAVE_TEMPLATES"},u={TEMPLATES:"apc_templates",SETTINGS:"apc_settings",OPENAI_KEY:"apc_openai_key",GROK_KEY:"apc_grok_key",GEMINI_KEY:"apc_gemini_key"},L=["Understand","Decide","Act","Compose"],Z=new Set(["default-structured-brief","analyze-article","community-debate-map","default-clean","extract-key-questions","lifestyle-recipe-card","lifestyle-buy-decision"]),H=[{id:"eng-ticket-analysis",name:"Ticket Analysis",label:"Ticket",description:"Summary, criteria, risks, next steps",category:"Understand",isDefault:!1,prompt:`You are a senior product engineer. Analyze ONLY the ticket below \u2014 do not invent information. Produce a developer-ready implementation brief.

Output ONLY the following markdown structure \u2014 nothing before or after:

## Summary
One crisp sentence: what is requested and why it matters.

## Goals
- 1\u20133 must-achieve outcomes

## Acceptance Criteria
1. Numbered, specific, testable conditions

## Technical Approach
High-level plan: steps, affected modules/APIs/DB changes, external dependencies.

## Tasks
- Task \xB7 Role (dev/qa/ux) \xB7 Estimate (S/M/L/XL) \xB7 Dependencies

## Risks & Mitigations
- Risk \u2192 mitigation (top 3 only)

## Open Questions
- Clarifications needed from author or stakeholders

## Priority
Low / Medium / High / Critical \u2014 one-sentence rationale

---

Ticket: [{title}]({url})

{content}`},{id:"eng-pr-review",name:"PR Review",label:"Code Review",description:"Changes, concerns, approvals, status",category:"Understand",isDefault:!1,prompt:`You are an elite code reviewer. Analyze ONLY the PR content below. Produce a concise, actionable review brief.

Output ONLY this exact markdown structure \u2014 nothing before or after:

## Summary
One paragraph: what the PR actually does and its intent.

## Impacted Areas
- Key files / modules / systems changed

## Findings

**Bugs / Logic**
- Issue \xB7 Severity (critical/high/medium/low) \xB7 Suggested fix

**Security / Performance**
- Issue \xB7 Severity \xB7 Suggested fix

**Tests / Coverage**
- Issue \xB7 Severity \xB7 Suggested fix

**Style / Maintainability**
- Issue \xB7 Severity \xB7 Suggested fix

## Test Recommendations
- What needs verification, missing test cases, quick smoke steps

## Verdict
Approve as-is / Approve with changes / Major rework needed / Reject \u2014 one-sentence reason.

## Post-Merge Follow-ups
- Optional cleanups / tech-debt items

---

Source: [{title}]({url})

{content}`},{id:"understand-structured-brief",name:"Structured Brief",label:"Brief",description:"Topic, key points, conclusions, open questions",category:"Understand",isDefault:!0,prompt:`You are a senior content analyst. Create a tight briefing from ONLY the source below. Do not add external facts.

Output ONLY this structure \u2014 nothing before or after:

## TL;DR
One powerful sentence summary.

## Audience
Who this is written for (persona, role, experience level).

## Key Takeaways
- 3\u20135 sharp, memorable bullets

## Evidence & Context
- 3\u20135 strongest claims, quotes, or data points from the source

## Conclusions
What was resolved, concluded, or recommended? Write "None yet" if unclear.

## Open Questions
What remains unclear, unresolved, or worth challenging?

---

Source: [{title}]({url})

{content}`},{id:"decide-brief",name:"Decision Brief",label:"Decision",description:"Options, trade-offs, recommendation",category:"Decide",isDefault:!1,prompt:`You're helping a friend decide. Read the content, figure out what it is, and respond accordingly.

If it's a movie, show, book, album, or anything creative: be a sharp critic. Pick a side \u2014 worth it or skip it. No hedging, no "it depends." Use "I" statements. Mediocre means no. End with a VERDICT that includes a star rating using \u2B50 and \u2606 and a score like 3.5/5.

If it's a restaurant, menu, or food: be a helpful friend who knows food. Point out the best dishes, flag healthy or light options, mention anything to avoid. No harsh criticism \u2014 just honest, useful picks. End with a VERDICT.

For anything else: make a clear call. Pick the best option and say why in two sentences. No sitting on the fence. End with a VERDICT.

Talk like a person. Short sentences. No jargon, no filler, no review clich\xE9s. Nothing before or after the analysis and VERDICT.

---

{content}`},{id:"decide-feature-request",name:"Feature Request Analysis",label:"Feature",description:"Problem, trade-offs, alternatives",category:"Decide",isDefault:!1,prompt:`You are a senior product engineer specializing in requirements distillation. Analyze ONLY the feature request below.

Output ONLY this structure \u2014 nothing before or after:

## Core Problem
One sentence: the real user pain or goal.

## User Stories
- As a [role], I want [feature] so that [benefit]
(3\u20134 stories)

## Acceptance Criteria
1. Numbered, testable conditions

## Edge Cases & Non-Functional
- Important boundaries, performance, security, accessibility needs

## MVP Scope
- In: \u2026
- Out / Later: \u2026

## Effort Sketch
Frontend: S / M / L
Backend: S / M / L
Infra / Other: S / M / L

---

Source: [{title}]({url})

{content}`},{id:"eng-action-items",name:"Extract Actions",label:"Actions",description:"Actions, next steps, blockers",category:"Act",isDefault:!1,prompt:`Extract every concrete action item from the content below. Output ONLY a numbered list \u2014 no introduction, no extra sentences.

Format each item:
1. **Action**: clear verb phrase
   **Owner**: role or person (infer if not explicit)
   **Due**: date / ASAP / none
   **Priority**: High / Medium / Low
   **Evidence**: short quote supporting this action

---

Source: [{title}]({url})

{content}`},{id:"extract-risks-blockers",name:"Risks & Blockers",label:"Risks",description:"Risks, blockers, assumptions",category:"Act",isDefault:!1,prompt:`Identify the most important risks and blockers from the content below. Output ONLY up to 8 items in this exact format \u2014 nothing else:

- **Title**: short name
  **Description**: 1\u20132 sentences
  **Likelihood**: Low / Medium / High
  **Impact**: Low / Medium / High / Critical
  **Mitigation**: concrete next step
  **Owner**: who should handle this
  **Escalation**: if stalled after 3 days \u2192 who / how

---

Source: [{title}]({url})

{content}`},{id:"lifestyle-smart-choice",name:"Smart Choice",label:"Recommend",description:"Options, trade-offs, quick verdict",category:"Act",isDefault:!1,prompt:`You're helping a friend pick the best option. Read the content, figure out what it is, and respond accordingly.

If it's a movie, show, book, album, or anything creative: be a sharp critic. Love it or hate it \u2014 no middle ground. Use "I" statements. Mediocre means no. End with a VERDICT that includes a star rating using \u2B50 and \u2606 and a score like 3.5/5.

If it's a restaurant menu or food: be a helpful advisor. Pick the best dishes, flag healthy and light options, call out anything worth skipping. Practical and direct \u2014 not harsh. End with a VERDICT.

For anything else: name the best option and say why. One clear pick, no hedging. End with a VERDICT.

Talk like a person. Short sentences. No jargon, no filler, no review clich\xE9s. Nothing before or after the analysis and VERDICT.

---

{content}`},{id:"write-compose-answer",name:"Draft Reply",label:"Reply",description:"Direct reply to a question or request",category:"Compose",isDefault:!1,prompt:`Draft a short, professional-yet-friendly reply for Slack or email based ONLY on the context below. Max 5\u20136 sentences.

Output ONLY the reply body text \u2014 no labels, no extras.

Structure: Start with an acknowledgment. Then give a direct answer or next step. Then a clear call-to-action (action + owner + due if relevant). End with a warm close.

---

{content}`},{id:"community-rewrite-comment",name:"Rewrite Comment",label:"Rewrite",description:"Professional, constructive rewrite",category:"Compose",isDefault:!1,prompt:`Rewrite the comment below to be professional, concise, and constructive while keeping the original meaning intact.

Output ONLY:

**Variant A \u2013 Short & direct**
(1\u20132 sentences)

**Variant B \u2013 Collaborative tone**
(2\u20134 sentences, warmer)

---

{content}`},{id:"write-email-helper",name:"Email Helper",label:"Email",description:"Short professional email draft",category:"Compose",isDefault:!1,prompt:`Write a professional, friendly email using ONLY the context below.

Output ONLY these four blocks \u2014 nothing before or after:

**Subject**
[6\u201310 words]

**Body**
(120\u2013180 words, natural tone)

**Sign-off choices**
1. Best regards, [Name]
2. Thanks & best, [Name]
3. Looking forward, [Name]

**Meeting proposals** (if scheduling is needed, next 1\u20132 business days)
- [Day, time]
- [Alternative day, time]

---

{content}`}],R={GREEN:4e3,YELLOW:16e3,MODEL_LIMITS:{"gpt-4o-mini":128e3,"gemini-2.0-flash":1048576,"grok-3-mini":131072}};function ee(e){return Math.ceil(e.length/4)}function te(e){return e<R.GREEN?"green":e<R.YELLOW?"yellow":"red"}async function A(){return(await chrome.storage.local.get(u.OPENAI_KEY))[u.OPENAI_KEY]??""}async function x(){return(await chrome.storage.local.get(u.GROK_KEY))[u.GROK_KEY]??""}async function P(){return(await chrome.storage.local.get(u.GEMINI_KEY))[u.GEMINI_KEY]??""}async function q(){let t=(await chrome.storage.local.get(u.TEMPLATES))[u.TEMPLATES];if(!t)return H;let o=new Map(H.map(s=>[s.id,s])),a=t.filter(s=>!Z.has(s.id)).map(s=>{let c=o.get(s.id);return c?{...s,name:c.name,label:c.label,category:c.category,description:c.description}:s}),f=new Set(a.map(s=>s.id)),b=H.filter(s=>!f.has(s.id));return b.length>0?[...a,...b]:a}async function U(){return{defaultTemplateId:"understand-structured-brief",theme:"dark",llmProvider:"openai",language:"en",...(await chrome.storage.sync.get(u.SETTINGS))[u.SETTINGS]}}async function V(e){let t=await U();await chrome.storage.sync.set({[u.SETTINGS]:{...t,...e}})}var Le={popup_preview:"Preview",popup_content_tab:"Content",popup_prompt_tab:"Prompt",popup_refresh_content:"Refresh content",popup_near_limit:"Near limit",popup_chat_placeholder:"Ask a follow-up\u2026",popup_no_key_prefix:"No API key set. Add it in\xA0",popup_options_link:"Options",popup_no_key_suffix:".",popup_copy_markdown:"Copy Markdown",popup_copy_prompt:"Copy Prompt",popup_copied:"Copied!",popup_ask_chatgpt:"Ask ChatGPT",popup_ask_gemini:"Ask Gemini",popup_ask_grok:"Ask Grok",popup_ask_ai:"Ask AI",popup_asking:"Asking\u2026",options_brand_sub:"Settings",options_nav_general:"General",options_nav_ai:"AI Connections",options_nav_library:"Prompt Library",options_nav_help:"Help",options_nav_about:"About",options_general_heading:"General",options_general_desc:"Configure default behaviour when the extension opens.",options_default_template:"Default Template",options_default_template_desc:"Pre-selected prompt when the popup opens",options_ai_provider:"AI Provider",options_ai_provider_desc:"Which service runs the analysis",options_theme:"Theme",options_theme_desc:"Interface colour scheme",options_theme_dark:"Dark",options_theme_light:"Light",options_language:"Language",options_language_desc:"Interface language",options_save:"Save Settings",options_saved:"\u2713 Saved",options_ai_heading:"AI Connections",options_ai_desc:"API keys are stored locally on your device and are never transmitted by this extension.",options_library_heading:"Prompt Library",options_library_desc:"Browse, search, and manage your prompt templates.",options_search_placeholder:"Search templates\u2026",options_help_heading:"Help",options_help_desc:"How Synto works and keyboard shortcuts.",options_about_heading:"About Synto",options_builtin:"built-in",options_new_template:"New Template",options_new_template_title:"Add new template",options_edit_template:"Edit Template",options_new_category:"New category\u2026",options_delete:"Delete",options_edit:"Edit",options_cancel:"Cancel",options_save_template:"Save Template",options_template_name_placeholder:"Template name",options_template_prompt_placeholder:"Write your prompt here\u2026",options_delete_confirm:"Delete this template?",options_no_results:"No templates yet.",options_no_results_search:'No templates matching\xA0"{q}"',status_connected:"Connected",status_not_configured:"Not Configured",error_no_key_openai:"No OpenAI API key. Add it in Options.",error_no_key_gemini:"No Gemini API key. Add it in Options.",error_no_key_grok:"No Grok API key. Add it in Options.",category_understand:"Understand",category_decide:"Decide",category_act:"Act",category_compose:"Compose",category_custom:"Custom","template_label_eng-ticket-analysis":"Ticket","template_label_eng-pr-review":"Code Review","template_label_understand-structured-brief":"Brief","template_label_decide-brief":"Decision","template_label_decide-feature-request":"Feature","template_label_eng-action-items":"Actions","template_label_extract-risks-blockers":"Risks","template_label_lifestyle-smart-choice":"Recommend","template_label_write-compose-answer":"Reply","template_label_community-rewrite-comment":"Rewrite","template_label_write-email-helper":"Email","template_name_eng-ticket-analysis":"Ticket Analysis","template_name_eng-pr-review":"PR Review","template_name_understand-structured-brief":"Structured Brief","template_name_decide-brief":"Decision Brief","template_name_decide-feature-request":"Feature Request Analysis","template_name_eng-action-items":"Extract Actions","template_name_extract-risks-blockers":"Risks & Blockers","template_name_lifestyle-smart-choice":"Smart Choice","template_name_write-compose-answer":"Draft Reply","template_name_community-rewrite-comment":"Rewrite Comment","template_name_write-email-helper":"Email Helper"},D=Le;var Ae={popup_preview:"Vorschau",popup_content_tab:"Inhalt",popup_prompt_tab:"Prompt",popup_refresh_content:"Inhalt aktualisieren",popup_near_limit:"Fast am Limit",popup_chat_placeholder:"Nachfrage stellen\u2026",popup_no_key_prefix:"Kein API-Schl\xFCssel. In den\xA0",popup_options_link:"Einstellungen",popup_no_key_suffix:"\xA0hinzuf\xFCgen.",popup_copy_markdown:"Markdown kopieren",popup_copy_prompt:"Prompt kopieren",popup_copied:"Kopiert!",popup_ask_chatgpt:"ChatGPT fragen",popup_ask_gemini:"Gemini fragen",popup_ask_grok:"Grok fragen",popup_ask_ai:"KI fragen",popup_asking:"Anfrage l\xE4uft\u2026",options_brand_sub:"Einstellungen",options_nav_general:"Allgemein",options_nav_ai:"AI-Verbindungen",options_nav_library:"Prompt-Bibliothek",options_nav_help:"Hilfe",options_nav_about:"\xDCber",options_general_heading:"Allgemein",options_general_desc:"Standardverhalten beim \xD6ffnen der Erweiterung festlegen.",options_default_template:"Standard-Template",options_default_template_desc:"Vorausgew\xE4hlter Prompt beim \xD6ffnen",options_ai_provider:"AI-Anbieter",options_ai_provider_desc:"Welcher Dienst die Analyse durchf\xFChrt",options_theme:"Theme",options_theme_desc:"Farbschema der Oberfl\xE4che",options_theme_dark:"Dunkel",options_theme_light:"Hell",options_language:"Sprache",options_language_desc:"Sprache der Benutzeroberfl\xE4che",options_save:"Einstellungen speichern",options_saved:"\u2713 Gespeichert",options_ai_heading:"AI-Verbindungen",options_ai_desc:"API-Schl\xFCssel werden lokal auf Ihrem Ger\xE4t gespeichert und nie \xFCbertragen.",options_library_heading:"Prompt-Bibliothek",options_library_desc:"Prompt-Templates durchsuchen und verwalten.",options_search_placeholder:"Templates suchen\u2026",options_help_heading:"Hilfe",options_help_desc:"So funktioniert Synto und Tastaturk\xFCrzel.",options_about_heading:"\xDCber Synto",options_builtin:"integriert",options_new_template:"Neues Template",options_new_template_title:"Neues Template hinzuf\xFCgen",options_edit_template:"Template bearbeiten",options_new_category:"Neue Kategorie\u2026",options_delete:"L\xF6schen",options_edit:"Bearbeiten",options_cancel:"Abbrechen",options_save_template:"Template speichern",options_template_name_placeholder:"Template-Name",options_template_prompt_placeholder:"Prompt hier eingeben\u2026",options_delete_confirm:"Dieses Template l\xF6schen?",options_no_results:"Keine Templates vorhanden.",options_no_results_search:'Keine Templates f\xFCr\xA0"{q}"',status_connected:"Verbunden",status_not_configured:"Nicht konfiguriert",error_no_key_openai:"Kein OpenAI API-Schl\xFCssel. Unter Einstellungen hinzuf\xFCgen.",error_no_key_gemini:"Kein Gemini API-Schl\xFCssel. Unter Einstellungen hinzuf\xFCgen.",error_no_key_grok:"Kein Grok API-Schl\xFCssel. Unter Einstellungen hinzuf\xFCgen.",category_understand:"Verstehen",category_decide:"Entscheiden",category_act:"Handeln",category_compose:"Verfassen",category_custom:"Benutzerdefiniert","template_label_eng-ticket-analysis":"Ticket","template_label_eng-pr-review":"Code Review","template_label_understand-structured-brief":"Briefing","template_label_decide-brief":"Entscheidung","template_label_decide-feature-request":"Feature","template_label_eng-action-items":"Aktionen","template_label_extract-risks-blockers":"Risiken","template_label_lifestyle-smart-choice":"Empfehlung","template_label_write-compose-answer":"Antwort","template_label_community-rewrite-comment":"Umschreiben","template_label_write-email-helper":"E-Mail","template_name_eng-ticket-analysis":"Ticket-Analyse","template_name_eng-pr-review":"PR Review","template_name_understand-structured-brief":"Strukturiertes Briefing","template_name_decide-brief":"Entscheidungshilfe","template_name_decide-feature-request":"Feature-Anfrage-Analyse","template_name_eng-action-items":"Aktionen extrahieren","template_name_extract-risks-blockers":"Risiken & Blocker","template_name_lifestyle-smart-choice":"Beste Wahl","template_name_write-compose-answer":"Antwort entwerfen","template_name_community-rewrite-comment":"Kommentar umschreiben","template_name_write-email-helper":"E-Mail-Assistent"},ne=Ae;var oe=D;function re(e){oe=e==="de"?ne:D}function p(e){return oe[e]??D[e]??e}function ie(e=document){e.querySelectorAll("[data-i18n]").forEach(t=>{t.textContent=p(t.getAttribute("data-i18n"))}),e.querySelectorAll("[data-i18n-placeholder]").forEach(t=>{t.setAttribute("placeholder",p(t.getAttribute("data-i18n-placeholder")))}),e.querySelectorAll("[data-i18n-title]").forEach(t=>{t.setAttribute("title",p(t.getAttribute("data-i18n-title")))})}var ae={openai:"gpt-4o-mini",gemini:"gemini-2.0-flash",grok:"grok-3-mini"},xe={openai:"popup_ask_chatgpt",gemini:"popup_ask_gemini",grok:"popup_ask_grok"},r={templates:[],selectedTemplateId:null,extracted:null,rawMarkdown:"",finalText:"",previewOpen:!0,previewTab:"content",chatStreaming:!1,chatHistory:[],llmProvider:"openai"};function S(){let e=xe[r.llmProvider];return e?p(e):p("popup_ask_ai")}var l=e=>document.getElementById(e),n={btnOptions:null,btnHelp:null,intentTabs:null,templateCards:null,errorMsg:null,tokenCount:null,tokenWarning:null,previewPanel:null,previewText:null,btnPreviewToggle:null,previewArrow:null,btnCopyMd:null,btnPreviewCopy:null,btnRefreshContent:null,btnProcess:null,chatPanel:null,chatNoKey:null,chatOptionsLink:null,chatMessages:null,chatInputRow:null,chatInput:null,btnChatSend:null};function se(){n.btnOptions=l("btn-options"),n.btnHelp=l("btn-help"),n.intentTabs=l("intent-tabs"),n.templateCards=l("template-cards"),n.errorMsg=l("error-msg"),n.tokenCount=l("token-count"),n.tokenWarning=l("token-warning"),n.previewPanel=l("preview-panel"),n.previewText=l("preview-text"),n.btnPreviewToggle=l("btn-preview-toggle"),n.previewArrow=l("preview-arrow"),n.btnCopyMd=l("btn-copy-md"),n.btnPreviewCopy=l("btn-preview-copy"),n.btnRefreshContent=l("btn-refresh-content"),n.btnProcess=l("btn-process"),n.chatPanel=l("chat-panel"),n.chatNoKey=l("chat-no-key"),n.chatOptionsLink=l("chat-options-link"),n.chatMessages=l("chat-messages"),n.chatInputRow=l("chat-input-row"),n.chatInput=l("chat-input"),n.btnChatSend=l("btn-chat-send")}function g(e){e?(n.errorMsg.textContent=e,n.errorMsg.classList.remove("hidden")):(n.errorMsg.classList.add("hidden"),n.errorMsg.textContent="")}function W(){let e=r.previewTab==="prompt";n.previewText.value=e?r.finalText:r.rawMarkdown,n.btnCopyMd.textContent=e?p("popup_copy_prompt"):p("popup_copy_markdown")}function T(e){r.previewOpen=e,n.previewPanel.classList.toggle("collapsed",!e),n.previewArrow.textContent=e?"\u25B4":"\u25BE",n.btnPreviewToggle.setAttribute("aria-expanded",String(e))}function ce(e){let t=ee(e),o=r.extracted?.source??"";n.tokenCount.textContent=`~${t.toLocaleString()}${o?` \xB7 ${o}`:""}`,n.tokenCount.className=`token-count ${te(t)}`;let i=ae[r.llmProvider],a=R.MODEL_LIMITS[i]??128e3;n.tokenWarning.classList.toggle("hidden",t<=a*.85)}async function le(e,t){try{await navigator.clipboard.writeText(e),Pe(t)}catch(o){g(`Copy failed: ${o instanceof Error?o.message:String(o)}`)}}function Pe(e){let t=e===n.btnCopyMd,o=t?e.textContent:null;e.classList.add("copy-success"),t&&(e.textContent=p("popup_copied")),setTimeout(()=>{e.classList.remove("copy-success"),t&&o&&(e.textContent=o)},2e3)}function pe(){n.btnPreviewToggle.addEventListener("click",()=>{T(!r.previewOpen)}),document.querySelectorAll(".preview-tab").forEach(e=>{e.addEventListener("click",()=>{document.querySelectorAll(".preview-tab").forEach(t=>{t.classList.remove("active"),t.setAttribute("aria-selected","false")}),e.classList.add("active"),e.setAttribute("aria-selected","true"),r.previewTab=e.dataset.tab,W(),r.previewOpen||T(!0)})}),n.btnCopyMd.addEventListener("click",async()=>{let e=r.previewTab==="prompt"?r.finalText:r.rawMarkdown;e&&await le(e,n.btnCopyMd)}),n.btnPreviewCopy.addEventListener("click",async()=>{let e=r.previewTab==="prompt"?r.finalText:r.rawMarkdown;e&&await le(e,n.btnPreviewCopy)})}function Se(e,t){let o=r.templates.find(a=>a.id===t);if(!o||!e)return"";let i=e.selection??e.content??"";return o.prompt.replace(/\{content\}/g,e.content??"").replace(/\{selection\}/g,i).replace(/\{title\}/g,e.title??"").replace(/\{url\}/g,e.url??"").replace(/\{siteName\}/g,e.siteName??"")}function K(){r.extracted&&(r.finalText=Se(r.extracted,r.selectedTemplateId),ce(r.finalText),n.btnCopyMd.disabled=!1,n.btnProcess.disabled=!1,W(),n.previewPanel.classList.contains("hidden")&&(n.previewPanel.classList.remove("hidden"),T(!0)))}var y=L[0],j={},N=null;function F(){let e=new Set(L),t=new Set;for(let o of r.templates)o.category&&!e.has(o.category)&&t.add(o.category);return[...L,...[...t].sort()]}function de(e){return r.templates.filter(t=>t.category===e)}function Ce(){if(r.selectedTemplateId){let o=r.templates.find(i=>i.id===r.selectedTemplateId);if(o?.category&&F().includes(o.category))return o.category}let e=localStorage.getItem("synto_intent"),t=F();return e&&t.includes(e)?e:t[0]??L[0]}function Ie(e){let t=n.previewText;if(!t||n.previewPanel.classList.contains("hidden")){e();return}t.classList.add("fading"),setTimeout(()=>{e(),t.classList.remove("fading")},90)}function z(){y=Ce(),j[y]=r.selectedTemplateId??"",Me(),me()}function Me(){let e=n.intentTabs;e.innerHTML="";for(let t of F()){let o=document.createElement("button");o.type="button",o.setAttribute("role","tab"),o.className="intent-tab"+(t===y?" active":""),o.setAttribute("aria-selected",String(t===y)),o.dataset.intent=t,o.textContent=p("category_"+t.toLowerCase())||t,e.appendChild(o)}}function me(){let e=n.templateCards;e.innerHTML="";for(let t of de(y)){let o=p("template_label_"+t.id)||t.label||t.name,i=p("template_name_"+t.id)||t.name,a=document.createElement("button");a.type="button",a.setAttribute("role","option"),a.setAttribute("aria-selected",String(t.id===r.selectedTemplateId)),a.setAttribute("tabindex",t.id===r.selectedTemplateId?"0":"-1"),a.setAttribute("aria-label",i),a.title=i,a.className="template-card"+(t.id===r.selectedTemplateId?" selected":""),a.dataset.id=t.id,a.textContent=o,e.appendChild(a)}}function Oe(){let e=n.templateCards.querySelectorAll(".template-card");for(let t of e){let o=t.dataset.id===r.selectedTemplateId;t.classList.toggle("selected",o),t.setAttribute("aria-selected",String(o)),t.setAttribute("tabindex",o?"0":"-1")}}function Re(){let e=n.intentTabs.querySelectorAll(".intent-tab");for(let t of e){let o=t.dataset.intent===y;t.classList.toggle("active",o),t.setAttribute("aria-selected",String(o))}}function He(e){y=e,localStorage.setItem("synto_intent",e);let t=j[e]??localStorage.getItem("synto_intent_sel_"+e),o=de(e),i=t&&o.find(a=>a.id===t)?t:o[0]?.id??null;i&&i!==r.selectedTemplateId&&(r.selectedTemplateId=i,V({defaultTemplateId:i}),K()),me(),Re()}function ue(e){e!==r.selectedTemplateId&&(r.selectedTemplateId=e,j[y]=e,localStorage.setItem("synto_intent_sel_"+y,e),Oe(),N!==null&&clearTimeout(N),N=setTimeout(()=>{V({defaultTemplateId:e}),Ie(()=>K()),N=null},150))}function De(e){let t=Array.from(n.templateCards.querySelectorAll(".template-card"));if(!t.length)return;let o=t.indexOf(document.activeElement);if(e.key==="ArrowRight"||e.key==="ArrowDown")e.preventDefault(),t[(o+1)%t.length].focus();else if(e.key==="ArrowLeft"||e.key==="ArrowUp")e.preventDefault(),t[(o-1+t.length)%t.length].focus();else if(e.key==="Enter"||e.key===" "){e.preventDefault();let i=document.activeElement;i.dataset.id&&ue(i.dataset.id)}}function ge(){n.intentTabs.addEventListener("click",e=>{let t=e.target.closest(".intent-tab");t?.dataset.intent&&He(t.dataset.intent)}),n.templateCards.addEventListener("click",e=>{let t=e.target.closest(".template-card");t?.dataset.id&&ue(t.dataset.id)}),n.templateCards.addEventListener("keydown",De)}var B="\uE000";function Ne(e){let t=e.trim(),o="";for(;t!==o;)o=t,t=t.replace(/^\d+\.\s+/,"").trim();return t||e}function fe(e){let t=d=>d.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"),o=[],i=t(e).replace(/```(?:\w*)\n?([\s\S]*?)```/g,(d,v)=>(o.push(`<pre><code>${v.trimEnd()}</code></pre>`),`${B}CODE${o.length-1}${B}`)),a=d=>d.replace(/`([^`]+)`/g,"<code>$1</code>").replace(/\*\*([^*\n]+)\*\*/g,"<strong>$1</strong>").replace(/\*([^*\n]+)\*/g,"<em>$1</em>").replace(/__([^_\n]+)__/g,"<strong>$1</strong>").replace(/_([^_\n]+)_/g,"<em>$1</em>"),f=d=>{let v=h=>h.replace(/^\||\|$/g,"").split("|").map(J=>J.trim()),M=h=>/^\|?[\s|:-]+\|?$/.test(h)&&h.includes("-"),k=d.findIndex(M);if(k<1)return d.map(h=>`${a(h)}<br>`).join("");let O=v(d[0]),Y=d.slice(k+1),Ee=O.map(h=>`<th>${a(h)}</th>`).join(""),Te=Y.map(h=>`<tr>${v(h).map(ke=>`<td>${a(ke)}</td>`).join("")}</tr>`).join("");return`<div class="md-table-wrap"><table class="md-table"><thead><tr>${Ee}</tr></thead><tbody>${Te}</tbody></table></div>`},b=i.split(`
`),s=[],c=!1,m=!1,_=[],w=()=>{c&&(s.push("</ul>"),c=!1),m&&(s.push("</ol>"),m=!1)},I=()=>{_.length&&(s.push(f(_)),_=[])},$=new RegExp(`^${B}CODE(\\d+)${B}$`);for(let d of b){let v=$.exec(d.trim());if(v){I(),w(),s.push(o[parseInt(v[1],10)]);continue}if(/^\|.+/.test(d)){w(),_.push(d);continue}I();let M=/^[-*] (.+)$/.exec(d);if(M){m&&(s.push("</ol>"),m=!1),c||(s.push("<ul>"),c=!0),s.push(`<li>${a(M[1])}</li>`);continue}let k=/^(\d+)\. (.+)$/.exec(d);if(k){c&&(s.push("</ul>"),c=!1),m||(s.push("<ol>"),m=!0);let Y=Ne(k[2]);s.push(`<li>${a(Y)}</li>`);continue}w();let O=/^#{1,3} (.+)$/.exec(d);if(O){s.push(`<strong>${a(O[1])}</strong><br>`);continue}if(d.trim()===""){!c&&!m&&s.push("<br>");continue}s.push(`${a(d)}<br>`)}return I(),w(),s.join("").replace(/(<br>){3,}/g,"<br><br>")}function C(e,t){let o=document.createElement("div");o.className=`chat-bubble-wrap ${e}`;let i=document.createElement("div");return i.className=`chat-bubble ${e}`,i.textContent=t,o.appendChild(i),n.chatMessages.appendChild(o),n.chatMessages.scrollTop=n.chatMessages.scrollHeight,i}function Ke(e,t){let o=e.parentElement;if(!o)return;let i=document.createElement("button");i.className="chat-bubble-copy",i.type="button",i.title="Copy response",i.setAttribute("aria-label","Copy response"),i.innerHTML=`
    <svg class="icon-copy" width="11" height="11" viewBox="0 0 24 24" fill="none"
         stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <rect x="9" y="9" width="13" height="13" rx="2"/>
      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
    </svg>
    <svg class="icon-check" width="11" height="11" viewBox="0 0 24 24" fill="none"
         stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="20 6 9 17 4 12"/>
    </svg>`,i.addEventListener("click",async()=>{try{await navigator.clipboard.writeText(t),i.classList.add("copy-success"),setTimeout(()=>i.classList.remove("copy-success"),2e3)}catch(a){g(`Copy failed: ${a instanceof Error?a.message:String(a)}`)}}),o.appendChild(i)}async function X(e,{url:t,model:o,key:i}){let a=await fetch(t,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${i}`},body:JSON.stringify({model:o,messages:r.chatHistory,stream:!0})});if(!a.ok){if(a.status===429){let m=a.headers.get("Retry-After"),_=m?` Retry after ${m}s.`:" Wait a moment and try again.";throw new Error(`Rate limited (429).${_}`)}let c=await a.json().catch(()=>({}));throw new Error(c.error?.message??`HTTP ${a.status}`)}let f="",b=a.body.getReader(),s=new TextDecoder;for(;;){let{done:c,value:m}=await b.read();if(c)break;for(let _ of s.decode(m).split(`
`)){if(!_.startsWith("data: "))continue;let w=_.slice(6).trim();if(w==="[DONE]")break;try{let $=JSON.parse(w).choices?.[0]?.delta?.content??"";f+=$,e.textContent=f,n.chatMessages.scrollTop=n.chatMessages.scrollHeight}catch{}}}e.classList.remove("streaming"),e.innerHTML=fe(f),r.chatHistory.push({role:"assistant",content:f}),Ke(e,f)}async function Be(e){let t=await A();if(!t)throw new Error(p("error_no_key_openai"));await X(e,{url:"https://api.openai.com/v1/chat/completions",model:"gpt-4o-mini",key:t})}async function Ge(e){let t=await P();if(!t)throw new Error(p("error_no_key_gemini"));await X(e,{url:"https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",model:"gemini-2.0-flash",key:t})}async function $e(e){let t=await x();if(!t)throw new Error(p("error_no_key_grok"));await X(e,{url:"https://api.x.ai/v1/chat/completions",model:"grok-3-mini",key:t})}async function _e(e){r.llmProvider==="gemini"?await Ge(e):r.llmProvider==="grok"?await $e(e):await Be(e)}async function Ye(){if(!r.finalText||r.chatStreaming)return;if(n.chatPanel.classList.remove("hidden"),T(!1),!await{openai:A,gemini:P,grok:x}[r.llmProvider]?.()){n.chatNoKey.classList.remove("hidden");return}n.chatNoKey.classList.add("hidden"),r.chatHistory.push({role:"user",content:r.finalText});let o=C("assistant","");o.classList.add("streaming"),r.chatStreaming=!0,n.btnProcess.disabled=!0,n.btnProcess.textContent=p("popup_asking"),n.btnProcess.classList.add("loading");try{await _e(o),n.chatInputRow.classList.remove("hidden")}catch(i){(o.parentElement??o).remove(),r.chatHistory.pop(),C("error",`Error: ${i instanceof Error?i.message:String(i)}`)}finally{r.chatStreaming=!1,n.btnProcess.disabled=!1,n.btnProcess.textContent=S(),n.btnProcess.classList.remove("loading"),o.classList.remove("streaming")}}function ye(e){e.style.height="auto",e.style.height=`${Math.min(e.scrollHeight,120)}px`}async function he(){let e=n.chatInput.value.trim();if(!e||r.chatStreaming)return;n.chatInput.value="",ye(n.chatInput),C("user",e),r.chatHistory.push({role:"user",content:e});let t=C("assistant","");t.classList.add("streaming"),r.chatStreaming=!0,n.btnChatSend.disabled=!0,n.btnProcess.disabled=!0;try{await _e(t)}catch(o){(t.parentElement??t).remove(),r.chatHistory.pop(),C("error",`Error: ${o instanceof Error?o.message:String(o)}`)}finally{r.chatStreaming=!1,n.btnChatSend.disabled=!1,n.btnProcess.disabled=!1,t.classList.remove("streaming"),n.chatInput.focus()}}function be(){n.btnProcess.addEventListener("click",Ye),n.chatInput.addEventListener("input",()=>{ye(n.chatInput)}),n.chatInput.addEventListener("keydown",e=>{e.key==="Enter"&&!e.shiftKey&&(e.preventDefault(),he())}),n.btnChatSend.addEventListener("click",he)}function G(){n.btnCopyMd.disabled=!0,n.btnProcess.disabled=!0}async function we(e){let t=await chrome.tabs.sendMessage(e,{type:Q.EXTRACT_CONTENT,mode:"markdown"});if(!t?.success)throw new Error(t?.error??"Extraction failed.");r.extracted=t,r.rawMarkdown=t.content,K()}async function E(){g(null),G(),n.previewPanel.classList.add("hidden"),r.chatHistory=[],n.chatInputRow.classList.add("hidden");let[e]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!e?.id||e.url?.startsWith("chrome://")||e.url?.startsWith("chrome-extension://")){g("Cannot extract from this page type. Navigate to a regular web page."),G();return}try{await we(e.id)}catch(t){let o=t instanceof Error?t.message:String(t);if(o?.includes("Receiving end does not exist"))try{await chrome.scripting.executeScript({target:{tabId:e.id},files:["content/content.js"]}),await we(e.id)}catch(i){g(i instanceof Error?i.message:String(i)),G()}else g(o),G()}}function ve(){document.addEventListener("keydown",e=>{!e.altKey||!e.shiftKey||e.key!=="Enter"||(e.preventDefault(),n.btnProcess.disabled||n.btnProcess.click())}),document.addEventListener("keydown",e=>{if(!(e.key==="a"||e.key==="A")||!(e.ctrlKey||e.metaKey))return;let t=e.target;t.tagName==="INPUT"||t.tagName==="TEXTAREA"||t.isContentEditable||(e.preventDefault(),E())})}async function qe(){se();let[e,t]=await Promise.all([q(),U()]);re(t.language??"en"),ie(),document.documentElement.dataset.theme=t.theme??"dark",r.templates=e,r.selectedTemplateId=t.defaultTemplateId??e[0]?.id??null,r.llmProvider=t.llmProvider??"openai",n.btnProcess.textContent=S(),z(),ge(),pe(),be(),ve(),n.btnOptions.addEventListener("click",()=>{chrome.runtime.openOptionsPage()}),n.btnHelp.addEventListener("click",()=>{chrome.tabs.create({url:chrome.runtime.getURL("options/options.html")+"#help"})}),n.chatOptionsLink.addEventListener("click",s=>{s.preventDefault(),chrome.tabs.create({url:chrome.runtime.getURL("options/options.html#ai-connections")})}),n.btnRefreshContent.addEventListener("click",()=>{E()});let o=document.getElementById("btn-content-info"),i=document.getElementById("content-info-popover"),a=navigator.platform.startsWith("Mac")?"\u2318A":"Ctrl+A";i.textContent=`Press ${a} to grab full content if it didn't work at first.`,o.addEventListener("click",s=>{s.stopPropagation(),i.classList.toggle("hidden")}),document.addEventListener("click",()=>{i.classList.add("hidden")}),await E(),await{openai:A,gemini:P,grok:x}[r.llmProvider]?.()&&n.chatNoKey?.classList.add("hidden"),chrome.tabs.onActivated.addListener(()=>{E()}),chrome.tabs.onUpdated.addListener((s,c,m)=>{c.status==="complete"&&m.active&&E()}),chrome.storage.onChanged.addListener((s,c)=>{c==="local"&&s[u.TEMPLATES]&&q().then(m=>{r.templates=m,z()}),s.llmProvider&&!r.chatStreaming&&(r.llmProvider=String(s.llmProvider.newValue??"openai"),n.btnProcess.textContent=S())})}qe().catch(e=>{console.error("[Synto] Init failed:",e),g(`Initialization error: ${e instanceof Error?e.message:String(e)}`)});})();
